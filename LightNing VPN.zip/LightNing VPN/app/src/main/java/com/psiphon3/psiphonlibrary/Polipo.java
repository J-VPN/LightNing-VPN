package com.psiphon3.psiphonlibrary;

/*
 * Copyright (c) 2012, Psiphon Inc.
 * All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

import java.io.*;
import java.net.*;
import mph.trunksku.apps.myssh.util.*;

public class Polipo
{
    // Singleton pattern

    private static Polipo m_polipo;

    public Object clone() throws CloneNotSupportedException
    {
        throw new CloneNotSupportedException();
    }

    public static synchronized Polipo getPolipo()
    {
        if (m_polipo == null)
        {
            m_polipo = new Polipo();
        }

        return m_polipo;
    }

    static Thread m_polipoThread;

    public static synchronized boolean isPolipoThreadRunning()
    {
        if (m_polipoThread != null)
        {
            return true;
        }

        return false;
    }

    public void runForever() 
    {
        // Polipo is chained to our local SOCKS proxy. We
        // run Polipo once and leave it running for the
        // lifetime of the main process. It should handle
        // the underlying SOCKS parent proxy going down
        // and coming back up. Leaving Polipo running
        // forever is compatible with the Polipo code
        // which is designed to run as a separate process
        // and which does not have any cleanup/restart
        // flow.

        // TODO: handle failed to start; e.g., port not available

        if (m_polipoThread != null)
        {
            return;
        }

        final int port = findAvailablePort(8080, 10);
        if(port == 0)
        {
            return;
        }

      //  PsiphonData.getPsiphonData().setHttpProxyPort(port);

        m_polipoThread = new Thread(
            new Runnable()
            {
                public void run() 
                {
                    runPolipo(
                        false ? 1 : 0,
                        port,
                        findAvailablePort(1080, 10));
                }
            });

        m_polipoThread.start();
    }

    public boolean isPortAvailable(int port)
    {
        Socket socket = new Socket();
        SocketAddress sockaddr = new InetSocketAddress("127.0.0.1", port);

        try 
        {
            socket.connect(sockaddr, 1000);
            // The connect succeeded, so there is already something running on that port
            return false;
        }
        catch (SocketTimeoutException e)
        {
            // The socket is in use, but the server didn't respond quickly enough
            return false;
        }
        catch (IOException e)
        {
            // The connect failed, so the port is available
            return true;
        }
        finally
        {
            if (socket != null)
            {
                try 
                {
                    socket.close();
                } 
                catch (IOException e) 
                {
                    /* should not be thrown */
                }
            }
        }
    }

    public int findAvailablePort(int start_port, int max_increment)
    {
        for(int port = start_port; port < (start_port + max_increment); port++)
        {
            if (isPortAvailable(port))
            {
                return port;
            }
        }

        return 0;
    }
    
    private native int runPolipo(int bindAll, int proxyPort, int localParentProxyPort);

    static
    {
        System.loadLibrary("polipo");
    }
}

