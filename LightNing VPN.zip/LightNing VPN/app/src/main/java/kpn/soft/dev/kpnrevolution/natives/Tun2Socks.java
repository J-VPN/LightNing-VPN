package kpn.soft.dev.kpnrevolution.natives;
import mph.trunksku.apps.myssh.logger.*;
import java.net.*;

public class Tun2Socks {
    static {
        System.loadLibrary((String)"tun2socks");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void Start(int n2, int n3, String string, String string2, String string3, String string4, String string5, boolean bl) {
        if (n2 != -1) {
            int n4 = bl ? 1 : 0;
            Tun2Socks.runTun2Socks(n2, n3, string, string2, string3, string4, string5, n4);
        	//Log.i("", "VPNService Started.");
		}
    }

    public static void Stop() {
        Tun2Socks.terminateTun2Socks();
		//Log.i("", "VPNService Stoped.");
    }

    public static void logTun2Socks(String string, String string2, String string3) {
        if (string2.equalsIgnoreCase("tun2socks")) {
            switch(string3){
				case "entering event loop":
					Log.i("", "VPNService Started.");
					break;
				case "exiting":
					Log.i("", "VPNService Stoped.");
					break;
			}
			//Log.i("", string2 + ": " + string3);
        }
    }

    private static native int runTun2Socks(int var0, int var1, String var2, String var3, String var4, String var5, String var6, int var7);

    private static native void terminateTun2Socks();
	
	public interface IProtectSocket {
        boolean doVpnProtect(Socket socket);
        boolean doVpnProtect(DatagramSocket socket);
    }
}


