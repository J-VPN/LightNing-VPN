package mph.trunksku.apps.myssh.service;



public class ProxyServer/* extends Service/* implements Tun2Socks.IProtectSocket*/ {
    /*private ServerSocket Server;
    private final String TAG = "ProxyServer Service";
    private boolean autoReplace;
    private String bufferRequest = "1024";
    private String bufferResponse = "4096";
    private OreoVPNService eProVpnService;
    private String headerPlus;
    private Intent intent;
    private boolean isRestart;
    private boolean isTerminate;
    private int localport;
    private String netDataString;
    private Builder notification;
    private NotificationManager notificationManager;
    private threadProxyServer p;
    private PendingIntent pendIntent;
    private boolean queryMethod;
    private String remotehost;
    private int remoteport;
    private SharedPreferences sp;
    private boolean splitMethod;

    private class threadProxyServer extends Thread {
        private boolean LoopingThread = true;
        private int ProxyPort;
        private String buffReq = "1024";
        private String buffRes = "4096";
        private String headerPlus = "";
        private Socket incoming;
        private String netDataString = "";
        private Socket outgoing;
        private String proxy = "";
        private boolean queryMethod;
        private boolean splitMethod;

        public threadProxyServer(String host, int remoteport) {
            this.ProxyPort = remoteport;
            this.proxy = host;
        }

        public void componentPayLoad(boolean radioButton2_p, boolean radioButton3_p, String headerPlus_p, String netData_p, String buffReq, String buffRes) {
            this.splitMethod = radioButton2_p;
            this.queryMethod = radioButton3_p;
            this.headerPlus = headerPlus_p;
            this.netDataString = netData_p;
            this.buffReq = buffReq;
            this.buffRes = buffRes;
        }

       /* private boolean isBlockApp() {
            for (ApplicationInfo appsInfo : ProxyServer.this.getPackageManager().getInstalledApplications(128)) {
                for (Object equals : Constraints.blockApp) {
                    if (appsInfo.packageName.equals(equals)) {
                        return true;
                    }
                }
            }
            return false;
        }*/

       /* public void run() {
            while (this.LoopingThread) {
                try {
                    this.incoming = ProxyServer.this.Server.accept();
                    this.outgoing = socketInject();
                    if (this.incoming != null) {
                        this.incoming.setKeepAlive(true);
                    }
                    if (this.outgoing != null) {
                        this.outgoing.setKeepAlive(true);
                    }
                    if (this.outgoing == null) {
                        Log.i("ProxyServer Service", "[" + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "] <font color=#FF0000>closed by remote proxy</font>");
                        this.incoming.close();
                    } else if (this.outgoing.isConnected()) {
                       // if (Boolean.valueOf(ProxyServer.this.preferences.getString("tun2socksPreferencesAll", "false")).booleanValue()) {
                            ProxyServer.this.doVpnProtect(this.outgoing);
                       // }
                        Log.i("ProxyServer Service", "[" + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "] connected to remote proxy");
                        ProxyThread.connect(this.incoming, this.outgoing, this.buffReq, this.buffRes, ProxyServer.this.autoReplace);
                    }
                } catch (Exception e) {
                }
            }
            interrupt();
        }

        public synchronized void sTop() {
            try {
                if (this.incoming != null) {
                    this.incoming.close();
                }
                if (this.outgoing != null) {
                    this.outgoing.close();
                }
                this.LoopingThread = false;
                if (isAlive()) {
                    interrupt();
                }
            } catch (Exception e) {
            }
        }

        private Socket socketInject() {
            Socket socket = null;
            WifiManager wifiManager = (WifiManager) ProxyServer.this.getSystemService("wifi");
          /* if (isBlockApp()) {
                Intent a = new Intent(ProxyServer.this, LogDialog.class);
                a.putExtra("title", "Sniffer Tool Detected");
                a.putExtra("msg", "Please uninstall sniffer application if you want use this application !!!");
                a.setFlags(268435456);
                ProxyServer.this.startActivity(a);
                ProxyServer.this.preferences.put("startPreferences", ProxyServer.this.encryptor.encrypt("false"));
                ProxyServer.this.stopForeground(true);
                ProxyServer.this.stopSelf();
                return null;
            } else if (wifiManager.isWifiEnabled()) {
                wifiManager.setWifiEnabled(false);
                ProxyServer.this.preferences.put("startPreferences", ProxyServer.this.encryptor.encrypt("false"));
                ProxyServer.this.stopForeground(true);
                ProxyServer.this.stopSelf();
                return null;
            } else {*/
                /*try {
                    Socket socket2 = new Socket(this.proxy, this.ProxyPort);
                    try {
                        OutputStream toServer = socket2.getOutputStream();
                        String readRequest;
                        int pos;
                        String[] splitSpace;
                        String PORT;
                        String IP;
                        String reqData;
                        Matcher cocok;
                        String hostQuery;
                        int pos2;
                        String qryInjection;
                        if (this.queryMethod) {
                            InputStream ToClient = socket2.getInputStream();
                            readRequest = new BufferedReader(new InputStreamReader(this.incoming.getInputStream())).readLine();
                            if (readRequest != null) {
                                readRequest = new StringBuilder(String.valueOf(readRequest)).toString();
                            }
                            byte[] buffer = new byte[512];
                            pos = this.netDataString.indexOf("netData");
                            splitSpace = readRequest.split(" ");
                            PORT = "80";
                            if (splitSpace[1].startsWith("http") || splitSpace[1].indexOf(":") <= 0) {
                                IP = splitSpace[1];
                            } else {
                                IP = splitSpace[1].split(":")[0];
                                PORT = splitSpace[1].split(":")[1];
                            }
                            if (pos < 0) {
                                reqData = this.netDataString.replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("\\r", "\r").replace("\\n", "\n");
                            } else if (this.netDataString.substring(pos + 7, (pos + 7) + 1).equals("@")) {
                                cocok = Pattern.compile("\\[.*?@(.*?)\\]").matcher(this.netDataString);
                                hostQuery = "";
                                if (cocok.find()) {
                                    hostQuery = cocok.group(1);
                                }
                                reqData = this.netDataString.replace("[netData@" + hostQuery.trim(), splitSpace[0] + " " + splitSpace[1] + "@" + hostQuery.trim() + " " + splitSpace[2]).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("\\r", "\r").replace("\\n", "\n").replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("]", "");
                            } else {
                                if (pos == 0) {
                                    pos = 1;
                                }
                                cocok = Pattern.compile("\\[(.*?)@.*?\\]").matcher(this.netDataString);
                                hostQuery = "";
                                if (cocok.find()) {
                                    hostQuery = cocok.group(1);
                                }
                                if (this.netDataString.substring(pos - 1, pos).equals("@")) {
                                    reqData = this.netDataString.replace(hostQuery.trim() + "@netData", splitSpace[0] + " " + hostQuery.trim() + "@" + splitSpace[1] + " " + splitSpace[2]).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("\\r", "\r").replace("\\n", "\n").replace("[", "").replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("]", "");
                                } else {
                                    reqData = this.netDataString.replace("[netData]", readRequest).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("\\r", "\r").replace("\\n", "\n");
                                }
                            }
                            toServer.write(reqData.getBytes());
                            toServer.flush();
                            int numberRead = ToClient.read(buffer);
                            if (numberRead == -1) {
                                socket = null;
                            } else {
                                String[] split = new String(buffer, 0, numberRead).split("\r\n");
                                if (split[0].toLowerCase(Locale.getDefault()).startsWith("http")) {
                                    if (split[0].substring(8).trim().indexOf("200") < 0) {
                                        socket = null;
                                    } else {
                                        String readRequest2 = new BufferedReader(new InputStreamReader(this.incoming.getInputStream())).readLine();
                                        if (readRequest2 != null) {
                                            readRequest2 = new StringBuilder(String.valueOf(readRequest2)).toString();
                                        }
                                        splitSpace = readRequest2.split(" ");
                                        if (splitSpace[1].startsWith("http") || splitSpace[1].indexOf(":") <= 0) {
                                            IP = splitSpace[1];
                                        } else {
                                            IP = splitSpace[1].split(":")[0];
                                            PORT = splitSpace[1].split(":")[1];
                                        }
                                        pos2 = this.headerPlus.indexOf("netData");
                                        if (pos2 < 0) {
                                            qryInjection = this.headerPlus.replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("\\r", "\r").replace("\\n", "\n");
                                        } else if (this.headerPlus.substring(pos2 + 7, (pos2 + 7) + 1).equals("@")) {
                                            cocok = Pattern.compile("\\[.*?@(.*?)\\]").matcher(this.headerPlus);
                                            hostQuery = "";
                                            if (cocok.find()) {
                                                hostQuery = cocok.group(1);
                                            }
                                            qryInjection = this.headerPlus.replace("[netData@" + hostQuery.trim(), splitSpace[0] + " " + splitSpace[1] + "@" + hostQuery.trim() + " " + splitSpace[2]).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("\\r", "\r").replace("\\n", "\n").replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("]", "");
                                        } else {
                                            if (pos2 == 0) {
                                                pos2 = 1;
                                            }
                                            cocok = Pattern.compile("\\[(.*?)@.*?\\]").matcher(this.headerPlus);
                                            hostQuery = "";
                                            if (cocok.find()) {
                                                hostQuery = cocok.group(1);
                                            }
                                            if (this.headerPlus.substring(pos2 - 1, pos2).equals("@")) {
                                                qryInjection = this.headerPlus.replace(hostQuery.trim() + "@netData", splitSpace[0] + " " + hostQuery.trim() + "@" + splitSpace[1] + " " + splitSpace[2]).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("\\r", "\r").replace("\\n", "\n").replace("[", "").replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("]", "");
                                            } else {
                                                qryInjection = this.headerPlus.replace("[netData]", readRequest2).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("\\r", "\r").replace("\\n", "\n");
                                            }
                                        }
                                        toServer.write(qryInjection.getBytes());
                                        toServer.flush();
                                        ToClient.read(buffer);
                                        socket = socket2;
                                    }
                                }
                                socket = socket2;
                            }
                        } else {
                            readRequest = new BufferedReader(new InputStreamReader(this.incoming.getInputStream())).readLine();
                            if (readRequest != null) {
                                readRequest = new StringBuilder(String.valueOf(readRequest)).toString();
                            }
                            splitSpace = readRequest.split(" ");
                            PORT = "80";
                            if (splitSpace[1].startsWith("http") || splitSpace[1].indexOf(":") <= 0) {
                                IP = splitSpace[1];
                            } else {
                                IP = splitSpace[1].split(":")[0];
                                PORT = splitSpace[1].split(":")[1];
                            }
                            pos = this.netDataString.indexOf("netData");
                            pos2 = this.headerPlus.indexOf("netData");
                            if (pos < 0) {
                                reqData = this.netDataString.replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("\\r", "\r").replace("\\n", "\n");
                            } else if (this.netDataString.substring(pos + 7, (pos + 7) + 1).equals("@")) {
                                cocok = Pattern.compile("\\[.*?@(.*?)\\]").matcher(this.netDataString);
                                hostQuery = "";
                                if (cocok.find()) {
                                    hostQuery = cocok.group(1);
                                }
                                reqData = this.netDataString.replace("[netData@" + hostQuery.trim(), splitSpace[0] + " " + splitSpace[1] + "@" + hostQuery.trim() + " " + splitSpace[2]).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("\\r", "\r").replace("\\n", "\n").replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("]", "");
                            } else {
                                if (pos == 0) {
                                    pos = 1;
                                }
                                cocok = Pattern.compile("\\[(.*?)@.*?\\]").matcher(this.netDataString);
                                hostQuery = "";
                                if (cocok.find()) {
                                    hostQuery = cocok.group(1);
                                }
                                if (this.netDataString.substring(pos - 1, pos).equals("@")) {
                                    reqData = this.netDataString.replace(hostQuery.trim() + "@netData", splitSpace[0] + " " + hostQuery.trim() + "@" + splitSpace[1] + " " + splitSpace[2]).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("\\r", "\r").replace("\\n", "\n").replace("[", "").replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("]", "");
                                } else {
                                    reqData = this.netDataString.replace("[netData]", readRequest).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("\\r", "\r").replace("\\n", "\n");
                                }
                            }
                            if (pos2 < 0) {
                                qryInjection = this.headerPlus.replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("\\r", "\r").replace("\\n", "\n");
                            } else if (this.headerPlus.substring(pos2 + 7, (pos2 + 7) + 1).equals("@")) {
                                cocok = Pattern.compile("\\[.*?@(.*?)\\]").matcher(this.headerPlus);
                                hostQuery = "";
                                if (cocok.find()) {
                                    hostQuery = cocok.group(1);
                                }
                                qryInjection = this.headerPlus.replace("[netData@" + hostQuery.trim(), splitSpace[0] + " " + splitSpace[1] + "@" + hostQuery.trim() + " " + splitSpace[2]).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("\\r", "\r").replace("\\n", "\n").replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("]", "");
                            } else {
                                if (pos2 == 0) {
                                    pos2 = 1;
                                }
                                cocok = Pattern.compile("\\[(.*?)@.*?\\]").matcher(this.headerPlus);
                                hostQuery = "";
                                if (cocok.find()) {
                                    hostQuery = cocok.group(1);
                                }
                                if (this.headerPlus.substring(pos2 - 1, pos2).equals("@")) {
                                    qryInjection = this.headerPlus.replace(hostQuery.trim() + "@netData", splitSpace[0] + " " + hostQuery.trim() + "@" + splitSpace[1] + " " + splitSpace[2]).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("\\r", "\r").replace("\\n", "\n").replace("[", "").replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("]", "");
                                } else {
                                    qryInjection = this.headerPlus.replace("[netData]", readRequest).replace("[METHOD]", splitSpace[0]).replace("[SSH]", splitSpace[1]).replace("[IP_PORT]", splitSpace[1]).replace("[IP]", IP).replace("[PORT]", PORT).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr] ", "\n\r").replace("[protocol]", splitSpace[2]).replace("[host]", IP).replace("[port]", PORT).replace("[host_port]", splitSpace[1]).replace("[ssh]", splitSpace[1]).replace("[ua]", Constraints.defaultUa).replace("\\r", "\r").replace("\\n", "\n");
                                }
                            }
                            if (this.splitMethod) {
                                toServer.write(reqData.getBytes());
                                toServer.flush();
                                toServer.write(qryInjection.getBytes());
                                toServer.flush();
                                socket = socket2;
                            } else if (reqData.contains("[split]")) {
                                String[] splitM = reqData.split("\\[split\\]");
                                for (String bytes : splitM)
								{
                                    toServer.write(bytes.getBytes());
                                    toServer.flush();
                                    Thread.sleep(1500);
                                }
                                socket = socket2;
                            } else if (reqData.contains("[delay]")) {
                                String[] splitM = reqData.split("\\[delay\\]");
                                for (String bytes2 : splitM)
								{
                                    toServer.write(bytes2.getBytes());
                                    toServer.flush();
                                    Thread.sleep(1500);
                                }
                                socket = socket2;
                            } else {
                                toServer.write(reqData.getBytes());
                                toServer.flush();
                                socket = socket2;
                            }
                        }
                        Log.i("ProxyServer Service", "[" + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "] <font color=#0000FF>sending payload</font>");
                    } catch (Exception e) {
                        socket = socket2;
                        Log.i("ProxyServer Service", "[" + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "] <font color=#FF0000>failed connect to remote proxy</font>");
                        return socket;
                    }
                } catch (Exception e2) {
                    Log.i("ProxyServer Service", "[" + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "] <font color=#FF0000>failed connect to remote proxy</font>");
                    return socket;
                }
                return socket;
            }
       // }
    }

    public IBinder onBind(Intent arg0) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        android.util.Log.i("ProxyServer Service", "Service Created");
        this.notificationManager = (NotificationManager) getSystemService("notification");
        this.intent = new Intent(this, MainActivity.class);
        this.intent.setFlags(67108864);
        this.pendIntent = PendingIntent.getActivity(this, 0, this.intent, 0);
        this.notification = new Builder(this);
        
        this.autoReplace = Boolean.valueOf(this.encryptor.decrypt(this.preferences.getString("autoReplacePreferences", this.encryptor.encrypt("false")))).booleanValue();
    }

    

    public void onDestroy() {
        super.onDestroy();
        android.util.Log.i("ProxyServer Service", "Service Destroy");
        if (this.Server != null) {
            try {
                this.Server.close();
            } catch (Exception e) {
            }
        }
        if (this.p != null) {
            this.p.sTop();
            if (!this.isTerminate) {
                Log.i("ProxyServer Service", "[" + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "] <font color=#FF0000>" + getString(R.string.app_name) + " stopped</font>");
            }
        }
       // this.preferences.put("startPreferences", this.encryptor.encrypt("false"));
        if (!this.isTerminate) {
            stopForeground(true);
           // notifyAlert(getString(R.string.forward_stop), getString(R.string.service_stopped), 16);
        }
        this.isTerminate = false;
    }

    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        android.util.Log.i("ProxyServer Service", getString(R.string.app_name) + " Task Removed");
    }

    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        if (intent == null) {
            this.localport = Integer.parseInt(this.encryptor.decrypt(this.preferences.getString("localPortService", this.encryptor.encrypt("1707"))));
            this.remotehost = this.encryptor.decrypt(this.preferences.getString("remoteHostService", this.encryptor.encrypt("")));
            this.remoteport = Integer.parseInt(this.encryptor.decrypt(this.preferences.getString("remotePortService", this.encryptor.encrypt("8000"))));
            this.splitMethod = Boolean.valueOf(this.encryptor.decrypt(this.preferences.getString("splitMethodService", this.encryptor.encrypt("false")))).booleanValue();
            this.queryMethod = Boolean.valueOf(this.encryptor.decrypt(this.preferences.getString("queryMethodService", this.encryptor.encrypt("false")))).booleanValue();
            this.netDataString = this.encryptor.decrypt(this.preferences.getString("netDataService", this.encryptor.encrypt("")));
            this.headerPlus = this.encryptor.decrypt(this.preferences.getString("headerPlusService", this.encryptor.encrypt("")));
            this.bufferRequest = this.preferences.getString("requestService", "1024");
            this.bufferResponse = this.preferences.getString("responseService", "4096");
        } else {
            this.isRestart = intent.getBooleanExtra("restart", false);
            this.isTerminate = intent.getBooleanExtra("terminate", false);
            if (this.isTerminate) {
                stopSelf();
                return;
            } else if (this.isRestart) {
                this.localport = Integer.parseInt(this.encryptor.decrypt(this.preferences.getString("localPortService", this.encryptor.encrypt("1707"))));
                this.remotehost = this.encryptor.decrypt(this.preferences.getString("remoteHostService", this.encryptor.encrypt("")));
                this.remoteport = Integer.parseInt(this.encryptor.decrypt(this.preferences.getString("remotePortService", this.encryptor.encrypt("8000"))));
                this.splitMethod = Boolean.valueOf(this.encryptor.decrypt(this.preferences.getString("splitMethodService", this.encryptor.encrypt("false")))).booleanValue();
                this.queryMethod = Boolean.valueOf(this.encryptor.decrypt(this.preferences.getString("queryMethodService", this.encryptor.encrypt("false")))).booleanValue();
                this.netDataString = this.encryptor.decrypt(this.preferences.getString("netDataService", this.encryptor.encrypt("")));
                this.headerPlus = this.encryptor.decrypt(this.preferences.getString("headerPlusService", this.encryptor.encrypt("")));
                this.bufferRequest = this.preferences.getString("requestService", "1024");
                this.bufferResponse = this.preferences.getString("responseService", "4096");
            } else {
                this.localport = intent.getIntExtra("localport", 1707);
               // this.preferences.put("localPortService", this.encryptor.encrypt(new StringBuilder(String.valueOf(this.localport)).toString()));
                this.remotehost = intent.getStringExtra("remotehost");
              //  this.preferences.put("remoteHostService", this.encryptor.encrypt(this.remotehost));
                this.remoteport = intent.getIntExtra("remoteport", 8000);
                //this.preferences.put("remotePortService", this.encryptor.encrypt(new StringBuilder(String.valueOf(this.remoteport)).toString()));
                this.splitMethod = intent.getBooleanExtra("splitMethod", false);
                //this.preferences.put("splitMethodService", this.encryptor.encrypt(new StringBuilder(String.valueOf(this.splitMethod)).toString()));
                this.queryMethod = intent.getBooleanExtra("queryMethod", false);
               // this.preferences.put("queryMethodService", this.encryptor.encrypt(new StringBuilder(String.valueOf(this.queryMethod)).toString()));
                this.netDataString = intent.getStringExtra("netData");
               // this.preferences.put("netDataService", this.encryptor.encrypt(this.netDataString));
                this.headerPlus = intent.getStringExtra("headerPlus");
               // this.preferences.put("headerPlusService", this.encryptor.encrypt(this.headerPlus));
                this.bufferRequest = intent.getStringExtra("bufferRequest");
                //this.preferences.put("requestService", this.bufferRequest);
                this.bufferResponse = intent.getStringExtra("bufferResponse");
               // this.preferences.put("responseService", this.bufferResponse);
            }
        }
        try {
            if (this.Server == null) {
                this.Server = new ServerSocket(this.localport);
            }
            Log.i("ProxyServer Service", "[" + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()) + "] <font color=#0000FF>" + getString(R.string.app_name) + " starting</font>");
           // notifyAlert(getString(R.string.forward_success), getString(R.string.service_running));
            savePreferences("remoteProxyPref", this.remotehost);
            this.p = new threadProxyServer(this.remotehost, this.remoteport);
            this.p.componentPayLoad(this.splitMethod, this.queryMethod, this.headerPlus, this.netDataString, this.bufferRequest, this.bufferResponse);
            this.p.start();
           /* this.preferences.put("startPreferences", this.encryptor.encrypt("true"));
            if (this.isRestart && !Utils.isWorked()) {
                Profile profile = ProfileFactory.getProfile();
                ProfileFactory.loadFromPreference();
                Intent it = new Intent(this, SSHTunnelService.class);
                Bundle bundle = new Bundle();
                bundle.putInt(Constraints.ID, profile.getId());
                it.putExtras(bundle);
                this.preferences.put(Constraints.ID, new StringBuilder(String.valueOf(profile.getId())).toString());
                startService(it);
                this.preferences.put("sshPreferencesAll", "true");
            }*/
       /* } catch (Exception e) {
            //this.preferences.put("startPreferences", this.encryptor.encrypt("false"));
            stopForeground(true);
            Toast.makeText(this, "PORT " + this.localport + " IS BEING USED BY ANOTHER PROGRAM ", 0).show();
            stopSelf();
            
        }
    }

    private void notifyAlert(String title, String info) {
        this.notification.setAutoCancel(false);
        this.notification.setTicker(title);
        this.notification.setContentTitle("eProxy");
        this.notification.setContentText(info);
        this.notification.setSmallIcon(R.drawable.ic_launcher);
        this.notification.setContentIntent(this.pendIntent);
        Notification barNotif = this.notification.build();
        this.notificationManager.cancel(R.string.app_name);
        startForeground(R.string.app_name, barNotif);
    }

    private void notifyAlert(String title, String info, int flags) {
        this.notification.setAutoCancel(false);
        this.notification.setTicker(title);
        this.notification.setContentTitle("eProxy");
        this.notification.setContentText(info);
        this.notification.setSmallIcon(R.drawable.ic_launcher);
        this.notification.setContentIntent(this.pendIntent);
        Notification barNotif = this.notification.build();
        this.notificationManager.cancel(R.string.app_name);
        this.notificationManager.notify(R.string.app_name, barNotif);
        this.notificationManager.cancel(R.string.app_name);
    }

    private void savePreferences(String key, String value) {
        if (this.sp == null) {
            this.sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        }
        Editor edit = this.sp.edit();
        edit.putString(key, value);
        edit.commit();
    }

    public boolean doVpnProtect(Socket socket) {
        if (this.eProVpnService == null) {
            this.eProVpnService = new OreoVPNService();
        }
        if (this.eProVpnService.protect(socket)) {
            android.util.Log.d("ProxyServer Service", "protect socket success");
            return true;
        }
        android.util.Log.d("ProxyServer Service", "protect socket failed");
        return false;
    }

    public boolean doVpnProtect(DatagramSocket socket) {
        return false;
    }*/
}

