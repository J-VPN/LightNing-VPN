package mph.trunksku.apps.myssh;

import android.*;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.support.annotation.*;
import android.support.v4.app.*;
import android.support.v4.content.*;
import android.support.v4n.view.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.text.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import com.github.angads25.filepicker.controller.*;
import com.github.angads25.filepicker.model.*;
import com.github.angads25.filepicker.view.*;
import com.github.mikephil.charting.charts.*;
import com.github.mikephil.charting.data.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import mph.trunksku.apps.myssh.async.*;
import mph.trunksku.apps.myssh.core.*;
import mph.trunksku.apps.myssh.db.*;
import mph.trunksku.apps.myssh.fragment.*;
import mph.trunksku.apps.myssh.model.*;
import mph.trunksku.apps.myssh.service.*;
import mph.trunksku.apps.myssh.util.*;
import mph.trunksku.apps.myssh.view.*;
import org.json.*;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import com.google.android.gms.ads.R;
import vmodz.signaturechecker.status404error.*;
import com.jcraft.jzlib.*;
import com.google.android.gms.ads.*;

public class MainActivity extends AppCompatActivity
{
	private CheckSign cs;
	public static ViewPager mPager;
	private android.content.DialogInterface.OnClickListener OnClickListener;
	private ScreenSliderPagerAdapter mPagerAdapter;
	private AdRequest adRequest;
	private AdView adView;
	public static Toolbar toolbar;
	private InterstitialAd mInterstitialAd;
	private static SharedPreferences sp;
    public static FilePickerDialog dialog;
    private String TAG;
    private static Context mContext;
	private DataBaseHelper db;
	private LineChart mChart;
	private Thread dataUpdate;
    private Handler vHandler = new Handler();
    private ArrayList<Entry> e1, e2;
    protected ArrayList<Float> mDownload, mUpload;
    private TextView dSpeed, uSpeed;
    protected List<Long> dList;
    protected List<Long> uList;
    DecimalFormat df = new DecimalFormat("#.##");
	private GraphHelper graph;
	public static EasyFlipView easyFlip;
	private JSONObject obj;
	private SharedPreferences defsp;
	Toast toast;
	private String[] torrentList = new String[] {"com.xunlei.downloadprovider",
		"com.epic.app.iTorrent",
		"hu.bute.daai.amorg.drtorrent",
		"com.mobilityflow.torrent.prof",
		"com.brute.torrentolite",
		"com.nebula.swift",
		"tv.bitx.media",
		"com.DroiDownloader",
		"bitking.torrent.downloader",
		"org.transdroid.lite",
		"com.mobilityflow.tvp",
		"com.gabordemko.torrnado",
		"com.frostwire.android",
		"com.vuze.android.remote",
		"com.akingi.torrent",
		"com.utorrent.web",
		"com.paolod.torrentsearch2",
		"com.delphicoder.flud.paid",
		"com.teeonsoft.ztorrent",
		"megabyte.tdm",
		"com.bittorrent.client.pro",
		"com.mobilityflow.torrent",
		"com.utorrent.client",
		"com.utorrent.client.pro",
		"com.bittorrent.client",
		"torrent",
		"com.AndroidA.DroiDownloader",
		"com.indris.yifytorrents",
		"com.delphicoder.flud",
		"com.oidapps.bittorrent",
		"dwleee.torrentsearch",
		"com.vuze.torrent.downloader",
		"megabyte.dm",
		"com.fgrouptech.kickasstorrents",
		"com.jrummyapps.rootbrowser.classic",
		"com.bittorrent.client",
		"hu.tagsoft.ttorrent.lite",
		"co.we.torrent"};
	private AdView mAdView;

	@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		new ApplicationBase().init(this);
		db = new DataBaseHelper(this);
        mContext = MainActivity.this;
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
		new Utils(this);
		toolbar = (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		sp = ApplicationBase.getSharedPreferences();
		defsp = ApplicationBase.getDefSharedPreferences();
		if (new Boolean(sp.getBoolean("firstStart", true)).booleanValue())
        {
			db.insertData(cfgData());
			Utils.v(cfgData());
			try
			{
				new Utility(this).checkAndExtract();
				xBinary.ExtractExecutable(this);
			}
			catch (IOException e)
			{}
			try
			{
				obj = new JSONObject(db.getData());
				sp.edit().putInt("VPNMod", R.id.mode_2).commit();
				sp.edit().putBoolean("Categorie", obj.getBoolean("Categories")).commit();
				sp.edit().putString("DefSquidPort", obj.getString("DefSquidPort")).commit();
				defsp.edit().putString("custom_update_url", obj.getString("DefUpdateURL")).commit();
				sp.edit().putString("ContactSupport", obj.getString("ContactSupport")).commit();
				sp.edit().putInt("CurrentConfigVersion", obj.getInt("UpdateVersion")).commit();
			}
			catch (JSONException e)
			{}

			sp.edit().putBoolean("firstStart", false).commit();
		}
		setContentView(R.layout.main);
		// Instantiate a ViewPager and a PagerAdapter.
        mPager = (ViewPager) findViewById(R.id.pager);
        mPagerAdapter = new ScreenSliderPagerAdapter(getFragmentManager(), this);
        /* Toolbar and slider should have the same elevation */
		sp.edit().putString("xUser","lightningvpn" ).commit();
		sp.edit().putString("xPass", "lightningvpn").commit();
        mPagerAdapter.addTab("HOME", HomeFragment.class);
        mPagerAdapter.addTab("LOG", LogFragment.class);
		cs = new CheckSign(this);
		cs.setSHA1("54:69:ff:7f:a3:e0:36:f7:a6:2e:7d:58:06:b6:b3:a6:d3:9b:84:ef");
		cs.check();
		//mPagerAdapter.addTab(R.string.faq, FaqFragment.class);
		
		mPager.setAdapter(mPagerAdapter);
        TabBarView tabs = (TabBarView) findViewById(R.id.sliding_tabs);
        tabs.setViewPager(mPager);
		easyFlip = (EasyFlipView) findViewById(R.id.easyFlipView);
	//	w_dialog();
		BottomNavigationViewNew navigation = (BottomNavigationViewNew) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
		mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-4445035246232542/2666706963");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
		mInterstitialAd.setAdListener(new AdListener() {
				@Override
				public void onAdLoaded() {
					// Code to be executed when an ad finishes loading.			
				}
				@Override
				public void onAdFailedToLoad(int errorCode) {
					// Code to be executed when an ad request fails.				
				}
				@Override
				public void onAdOpened() {
					// Code to be executed when the ad is displayed.			
					}
				@Override
				public void onAdLeftApplication() {
					// Code to be executed when the user has left the app.			
					}
				@Override
				public void onAdClosed() {			
					// Code to be executed when when the interstitial ad is closed.
					mInterstitialAd.loadAd(new AdRequest.Builder().build());
				}
			});
		AdView adView = new AdView(this);
		adView.setAdSize(AdSize.BANNER);
		adView.setAdUnitId("ca-app-pub-9017186586438826/4554383878");
		MobileAds.initialize(this,
							 "ca-app-pub-9017186586438826~1417148947");

        mAdView = (AdView) findViewById(R.id.adView1);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
		mAdView.setAdListener(new AdListener() {
				@Override
				public void onAdLoaded() {
					// Code to be executed when an ad finishes loading.	
					}
				@Override
				public void onAdFailedToLoad(int errorCode) {
					// Code to be executed when an ad request fails.
				}
				@Override
				public void onAdOpened() {
					// Code to be executed when an ad opens an overlay that
					// covers the screen.
				}
				@Override
				public void onAdLeftApplication() {
					// Code to be executed when the user has left the app.
				}
				@Override
				public void onAdClosed() {
					// Code to be executed when when the user is about to return
					// to the app after tapping on an ad.
				}
			});	
        //calling sync state is necessay or else your hamburger icon wont show up
		mChart = (LineChart) findViewById(R.id.chart1);
		// mChart.setViewPortOffsets(0, 0, 0, 0);
		//mChart.setBackgroundColor(Color.rgb(104, 241, 175));
		graph = GraphHelper.getHelper().with(this).color(Color.parseColor(getString(R.color.harlie_color))).chart(mChart);
        DialogProperties properties=new DialogProperties();
        properties.selection_mode = DialogConfigs.SINGLE_MODE;
        properties.selection_type = DialogConfigs.FILE_SELECT;
        //Instantiate FilePickerDialog with Context and DialogProperties.
        dialog = new FilePickerDialog(this, properties);
        dialog.setTitle("Select a File");
        dialog.setPositiveBtnName("Select");
        dialog.setNegativeBtnName("Cancel");
        dialog.setDialogSelectionListener(new DialogSelectionListener() {
                @Override
                public void onSelectedFilePaths(final String[] files)
				{
                    for (String path:files)
					{
                        File file=new File(path);
                        if (file.getName().endsWith(".mz") || file.getName().endsWith(".MZ"))
						{
                            String data = inet(file.getAbsolutePath());
                            if (TextUtils.isEmpty(data))
							{
                                LayoutInflater inflater = getLayoutInflater();
								View layout = inflater.inflate(R.layout.toast1,(ViewGroup) findViewById(R.id.custom_toast_container));
								TextView text = (TextView) layout.findViewById(R.id.textCustom);
								text.setText("Invalid File!");
								Toast toast = new Toast(getApplicationContext());
								toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
								toast.setDuration(Toast.LENGTH_LONG);
								toast.setView(layout);
								toast.show();
                            }
							else
							{
                                try
								{
                                    JSONObject obj = new JSONObject(XxTea.decryptBase64StringToString(data, "123456"));
                                    if (obj.getInt("UpdateVersion") == sp.getInt("CurrentConfigVersion", 0))
									{
                                        
										LayoutInflater inflater = getLayoutInflater();
										View layout = inflater.inflate(R.layout.toast2,
																	   (ViewGroup) findViewById(R.id.custom_toast_container));
										TextView text = (TextView) layout.findViewById(R.id.textCustom);
										text.setText("Already used the config version.");
										Toast toast = new Toast(getApplicationContext());
										toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
										toast.setDuration(Toast.LENGTH_LONG);
										toast.setView(layout);
										toast.show();
                                    }
									else
									{
                                        db.updateData("1", data);
										sp.edit().putInt("ServerSpin0", 0).commit();
										sp.edit().putInt("ServerSpin1", 0).commit();
										sp.edit().putInt("NetworkSpin0", 0).commit();
										sp.edit().putInt("NetworkSpin1", 0).commit();
                                       	sp.edit().putBoolean("Categorie", obj.getBoolean("Categories")).commit();
										sp.edit().putString("DefSquidPort", obj.getString("DefSquidPort")).commit();
										defsp.edit().putString("custom_update_url", obj.getString("DefUpdateURL")).commit();
										sp.edit().putString("ContactSupport", obj.getString("ContactSupport")).commit();
										AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this)
                                            .setCancelable(false)
                                            .setTitle("What's New");
                                        StringBuffer sb = new StringBuffer();
                                        JSONArray jarr = obj.getJSONArray("ReleaseNotes");
                                        for (int i=0;i < jarr.length();i++)
                                        {
                                            sb.append(jarr.getString(i) + "\n");
                                        }
										adb.setMessage(sb.toString())
                                            .setPositiveButton("Update", new DialogInterface.OnClickListener(){
                                                @Override
                                                public void onClick(DialogInterface p1, int p2)
												{
                                                    // TODO: Implement this method
                                                    if (OreoService.isRunning)
													{
                                                        stopService(new Intent(MainActivity.this, OreoService.class));
                                                    }
													HomeFragment.upRefresh();
                                                    mRestart(MainActivity.this);
                                                }
                                            })
                                            .setNegativeButton("Later", null)
                                            .create().show();
                                        sp.edit().putInt("CurrentConfigVersion", obj.getInt("UpdateVersion")).commit();
                                    }
                                }
								catch (Exception e)
								{
                                    LogFragment.addLog(e.getMessage());
                                }
                            }
                            Toast.makeText(mContext,data , 0).show();
                        }
						else
						{
							LayoutInflater inflater = getLayoutInflater();
							View layout = inflater.inflate(R.layout.toast1,
														   (ViewGroup) findViewById(R.id.custom_toast_container));
							TextView text = (TextView) layout.findViewById(R.id.textCustom);
							text.setText("Invalid File!");
							Toast toast = new Toast(getApplicationContext());
							toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
							toast.setDuration(Toast.LENGTH_LONG);
							toast.setView(layout);
							toast.show();
                        }
                    }
                }
			});
		mDownload = new ArrayList<>();
		mUpload = new ArrayList<>();

		 setGraph();
		liveData();
		new TorrentDetection(this, torrentList).init();
        int permissionCheck = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED)
		{
     //       ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
		}
    }

	private void setGraph()
	{
		// TODO: Implement this method
	}

	private BottomNavigationViewNew.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
	= new BottomNavigationViewNew.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
			if (mInterstitialAd.isLoaded()) {
				mInterstitialAd.show();
			} else {
				Log.d("TAG", "The interstitial wasn't loaded yet.");
			}
			switch (item.getItemId()) {
              case R.id.about1:
				  info();
				  mInterstitialAd.show();
				  return true;
				  case R.id.server_update:
					  server_update();
					mInterstitialAd.show();  
					  return true;			  
				case R.id.nav_vpn_mode:
					if (OreoService.isRunning)
					{
						LayoutInflater inflater = getLayoutInflater();
						View layout = inflater.inflate(R.layout.toast1,(ViewGroup) findViewById(R.id.custom_toast_container));
						TextView text = (TextView) layout.findViewById(R.id.textCustom);
						text.setText("Disconnect first to change vpn mode!");
						Toast toast = new Toast(getApplicationContext());
						toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
						toast.setDuration(Toast.LENGTH_LONG);
						toast.setView(layout);
						toast.show();
						mInterstitialAd.show();
						}
					else
					{
						new VPNModeDialog(MainActivity.this).show();
						mInterstitialAd.show();
					}
					return true;
				case R.id.nav_exit:
					quiter();
					mInterstitialAd.show();
					return true;
				case R.id.nav_setting:
					startActivity(new Intent(MainActivity.this, SettingActivity.class));
					mInterstitialAd.show();
					return true;
            }
            return false;
        }

    };
	
	private void w_dialog()
	{
		AlertDialog.Builder builder6 = new AlertDialog.Builder(MainActivity.this);
		//	builder6.setTitle("");
		builder6.setView(getLayoutInflater().inflate(R.layout.w_dialog,null));
		builder6.setCancelable(true);
		builder6.setPositiveButton("ok",(OnClickListener));	
		builder6.create().show();
	}
	
	private void info()
	{
		AlertDialog.Builder builder6 = new AlertDialog.Builder(MainActivity.this);
	//	builder6.setTitle("");
		builder6.setView(getLayoutInflater().inflate(R.layout.activity_about,null));
		builder6.setCancelable(true);
		builder6.setPositiveButton("ok",(OnClickListener));
		builder6.create().show();
	}
	/*private void webpanel(){
			openInCustomTab("http://hxphpanel-vpn.ml/");
		}
	private void openInCustomTab(String url){

        Uri websiteUri;
        if(!url.contains("://") && !url.contains("http://")){
            websiteUri = Uri.parse("http://" + url);}else {
            websiteUri = Uri.parse(url);
        }

        CustomTabsIntent.Builder customtabintent = new CustomTabsIntent.Builder();
        customtabintent.setToolbarColor(getResources().getColor(R.color.harlie_color));
        customtabintent.setShowTitle(true);

        if(chromeInstalled()){
            customtabintent.build().intent.setPackage("com.android.chrome");
        }
        customtabintent.build().launchUrl(MainActivity.this,websiteUri);
    }
	
	*/
	public void liveData()
	{
        dataUpdate = new Thread(new Runnable() {
				private int progressStatus;
				@Override
				public void run()
				{
					while (!dataUpdate.getName().equals("stopped"))
					{

						vHandler.post(new Runnable() {

								@Override
								public void run()
								{
									addDataSet();
									if (OreoService.isRunning)
									{
										graph.start();
									}
									else
									{
										graph.stop();
									}
								}

								private void addDataSet()
								{
									// TODO: Implement this method
								}
							});

						try
						{
							Thread.sleep(1000);
						}
						catch (InterruptedException e)
						{
							e.printStackTrace();
						}
						  progressStatus--;
					}

				}
			});

        dataUpdate.setName("started");
        dataUpdate.start();
    }
	
	/*private boolean chromeInstalled(){
        try{
            getPackageManager().getPackageInfo("com.android.chrome", 0);
            return true;
        } catch (Exception e){
            return false;
       } } */
	private void showTheDialog(final String appPackageName, String versionFromRemoteConfig){
        final AlertDialog dialog = new AlertDialog.Builder(this)
			.setTitle("Update")
			.setMessage("This version is absolete, please update to version: "+versionFromRemoteConfig)
			.setPositiveButton("UPDATE", null)
			.show();

        dialog.setCancelable(false);

        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        positiveButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					try {
						startActivity(new Intent(Intent.ACTION_VIEW,
												 Uri.parse("market://details?id=" + appPackageName)));
					}
					catch (android.content.ActivityNotFoundException anfe) {
						startActivity(new Intent(Intent.ACTION_VIEW,
												 Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
					}
				}
			});
	}

    private PackageInfo pInfo;
    public int getVersionCode() {
        pInfo = null;
        try {
            pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            Log.i("MYLOG", "NameNotFoundException: "+e.getMessage());
        }
        return pInfo.versionCode;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	{
        switch (requestCode)
		{
            case 101:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
				{          
					LayoutInflater inflater = getLayoutInflater();
					View layout = inflater.inflate(R.layout.toast2,(ViewGroup) findViewById(R.id.custom_toast_container));
					TextView text = (TextView) layout.findViewById(R.id.textCustom);
					text.setText("Application permissiom granted");
					Toast toast = new Toast(getApplicationContext());
					toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
					toast.setDuration(Toast.LENGTH_LONG);
					toast.setView(layout);
					toast.show();
                }
				else
				{       
					LayoutInflater inflater = getLayoutInflater();
					View layout = inflater.inflate(R.layout.toast2,
												   (ViewGroup) findViewById(R.id.custom_toast_container));
					TextView text = (TextView) layout.findViewById(R.id.textCustom);
					text.setText("Please grant Permission to Access more features.");
					Toast toast = new Toast(getApplicationContext());
					toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
					toast.setDuration(Toast.LENGTH_LONG);
					toast.setView(layout);
					toast.show();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

	@Override
    public void onPause()
	{
        // This method should be called in the parent Activity's onPause() method.
		if (adView != null) {
			adView.pause();
		}
        super.onPause();
    }

    @Override
    public void onDestroy()
	{
        // This method should be called in the parent Activity's onDestroy() method.
        if (adView != null) {
			adView.destroy();
		}
        super.onDestroy();
    }
	
	@Override
	protected void onResume()
	{
		new Timer().schedule(new TimerTask(){
				@Override
				public void run()
				{
					runOnUiThread(new Runnable()
						{

							@Override
							public void run()
							{
								if (adView != null) {
									adView.resume();
								}
								if (OreoService.isRunning)
								{						
								}					
								// TODO: Implement this method
							}
						});
					// TODO: Implement this method
				}
			}, 0,1000);
		super.onResume();
	}
    public static void account()
	{
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View inflate = inflater.inflate(R.layout.layout_account, (ViewGroup) null);
        final EditText edUser = (EditText) inflate.findViewById(R.id.edUser);
        edUser.setText(sp.getString("xUser", ""));
        final EditText edPass = (EditText) inflate.findViewById(R.id.edPassword);
        edPass.setText(sp.getString("xPass", ""));
        new AlertDialog.Builder(mContext)
            .setTitle(mContext.getString(R.string.app_name) + " Account")
            .setView(inflate)
            .setPositiveButton("SAVE", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    // TODO: Implement this method
                    sp.edit().putString("xUser", edUser.getText().toString()).commit();
                    sp.edit().putString("xPass", edPass.getText().toString()).commit();
                }
            })
            .setNegativeButton("CANCEL", null)
            .create().show();
    }

    public void mRestart(Context c)
	{
        try
		{
            if (c != null)
			{
                PackageManager pm = c.getPackageManager();
                if (pm != null)
				{
                    Intent mStartActivity = pm.getLaunchIntentForPackage(
                        c.getPackageName()
                    );
                    if (mStartActivity != null)
					{
                        mStartActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        int mPendingIntentId = android.os.Process.myPid();
                        PendingIntent mPendingIntent = PendingIntent
                            .getActivity(c, mPendingIntentId, mStartActivity,
                                         PendingIntent.FLAG_CANCEL_CURRENT);
                        AlarmManager mgr = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
                        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
                        //kill the application
                        System.exit(0);
                    }
					else
					{
                        Log.e(TAG, "Was not able to restart application, mStartActivity null");
                    }
                }
				else
				{
                    Log.e(TAG, "Was not able to restart application, PM null");
                }
            }
			else
			{
                Log.e(TAG, "Was not able to restart application, Context null");
            }
        }
		catch (Exception ex)
		{
            Log.e(TAG, "Was not able to restart application");
        }
    }

    public String inet(String path)
    {
        try
        {
            InputStream openRawResource = new FileInputStream(path);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            for (int read = openRawResource.read(); read != -1; read = openRawResource.read())
            {
                byteArrayOutputStream.write(read);
            }
            openRawResource.close();
            return byteArrayOutputStream.toString();
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return "";
        }
    }
	public String cfgData()
    {
        InputStream openRawResource = getResources().openRawResource(R.raw.config);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try
        {
            for (int read = openRawResource.read(); read != -1; read = openRawResource.read())
            {
                byteArrayOutputStream.write(read);
            }
            openRawResource.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return byteArrayOutputStream.toString();
    }
	@Override
	public void onBackPressed(){
		
			quiter();
	}
	
	private void server_update(){
		if (OreoService.isRunning){
			showSnack("Disconnect the VPN Service!");
		} else {
			new AlertDialog.Builder(MainActivity.this)
				.setCancelable(false)
				.setTitle("Config Updater")
				.setMessage(" Online Update - requires internet connection.")
				.setPositiveButton("Online", new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						// TODO: Implement this method
						new UpdateAsync(MainActivity.this, new UpdateAsync.Listener() {
								@Override
								public void onCompleted(String config)
								{
									// TODO: Implement this method
									try
									{
										JSONObject obj = new JSONObject(XxTea.decryptBase64StringToString(config, "123456"));
										if (obj.getInt("UpdateVersion") == sp.getInt("CurrentConfigVersion", 0))
										{
											AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
											alertDialogBuilder.setView(R.layout.updated);
											alertDialogBuilder.setPositiveButton("ok", null);
											alertDialogBuilder.setCancelable(true);
											AlertDialog alertDialog = alertDialogBuilder.create();
											alertDialog.show();
										}
										else
										{
											db.updateData("1", config);
											sp.edit().putInt("ServerSpin0", 0).commit();
											sp.edit().putInt("ServerSpin1", 0).commit();
											sp.edit().putInt("NetworkSpin0", 0).commit();
											sp.edit().putInt("NetworkSpin1", 0).commit();
											sp.edit().putBoolean("Categorie", obj.getBoolean("Categories")).commit();
											sp.edit().putString("DefSquidPort", obj.getString("DefSquidPort")).commit();
											defsp.edit().putString("custom_update_url", obj.getString("DefUpdateURL")).commit();
											sp.edit().putString("ContactSupport", obj.getString("ContactSupport")).commit();
											AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this)
												.setCancelable(false)
												.setTitle("What's New");
											StringBuffer sb = new StringBuffer();
											JSONArray jarr = obj.getJSONArray("ReleaseNotes");
											for (int i=0;i < jarr.length();i++)
											{
												sb.append(jarr.getString(i) + "\n");
											}
											adb.setMessage(sb.toString())
												.setPositiveButton("Finish!!", new DialogInterface.OnClickListener(){
													@Override
													public void onClick(DialogInterface p1, int p2)
													{
														// TODO: Implement this method
														if (OreoService.isRunning)
														{
															MainActivity.this.stopService(new Intent(MainActivity.this, OreoService.class));
														}
														HomeFragment.upRefresh();
														mRestart(mContext);
													}
												})
												.setNegativeButton("No!!", null)
												.create().show();
											sp.edit().putInt("CurrentConfigVersion", obj.getInt("UpdateVersion")).commit();
										}
									}
									catch (Exception e)
									{
										LogFragment.addLog(e.getMessage());
									}
								}
								@Override
								public void onCancelled()
								{
									// TODO: Implement this method
								}
								@Override
								public void onException(String ex)
								{
									// TODO: Implement this method
									showSnack("Something went wrong, Please try again.");
								}
							}).execute();
					}
				}).setNegativeButton("Cancel", null)
				.create().show();
		}
}

	private void showSnack(String p0)
	{
		// TODO: Implement this method
	}private void quiter()
    {
        AlertDialog.Builder builder3 = new AlertDialog.Builder(MainActivity.this);
        builder3.setMessage("Do you want to minimize or exit?");
        builder3.setPositiveButton("EXIT", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    // TODO: Implement this method
					stopService(new Intent(MainActivity.this, OreoService.class));
                    new Semaphore(0, true).release();
                    android.os.Process.killProcess(android.os.Process.myPid());
                    System.exit(0);
                }
            });
        builder3.setNegativeButton("MINIMIZE", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    // TODO: Implement this method
                    Intent intent = new Intent("android.intent.action.MAIN");
                    intent.addCategory("android.intent.category.HOME");
                    intent.setFlags(268435456);
                    startActivity(intent);
                }
            });
        builder3.setNeutralButton("CANCEL", null);
	
        builder3.show();
	}
}
