package mph.trunksku.apps.myssh.fragment;
import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.support.design.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import net.finalfixvpn.ml2.R.*;
import java.util.*;
import mph.trunksku.apps.myssh.*;
import mph.trunksku.apps.myssh.adapter.*;
import mph.trunksku.apps.myssh.async.*;
import mph.trunksku.apps.myssh.db.*;
import mph.trunksku.apps.myssh.model.*;
import mph.trunksku.apps.myssh.service.*;
import mph.trunksku.apps.myssh.util.*;
import mph.trunksku.apps.myssh.view.*;
import org.json.*;
import android.support.v7.app.AlertDialog;
import mph.trunksku.apps.myssh.adapter.SpinnerAdapter;
import com.google.android.gms.ads.*;
import com.github.angads25.filepicker.view.*;
import com.status404error.blockapps.*;

public class HomeFragment extends Fragment implements StatusChangeListener
{
	 private View mView;
	private static ArrayList<HashMap<String, String>> serverList = new ArrayList<HashMap<String, String>>();
	public ArrayList<String> serverTypeList = new ArrayList();
	public static ArrayList<String> networkList = new ArrayList();
	public ArrayList<String> networkTypeList = new ArrayList();
	private ArrayAdapter<String> adapter;

	public static Config utils;

	private static SharedPreferences sp;

	public static ArrayList Vpnmod = new ArrayList();
	public static Spinner serverSpin;

	public static Spinner networkSpin;
	
	public static SpinnerAdapter serverAdapt;

	private static DataBaseHelper db;

	private FilePickerDialog dialog;

	private Spinner serverTypeSpin;

	//private Spinner networkTypeSpin;
	private InterstitialAd mInterstitialAd;
	private AdView adView;

	private AdRequest adRequest;
	
	private Button start;

	private EditText userN;

	private MaterialEditText passW;

	// public static ArrayAdapter networkAdapt;

	public static NetworkAdapter networkAdapt;
	
	private SharedPreferences defsp;

	private static LinearLayout serverTypeLayout;

	private BlockApps b;
	
    //private BottomSheetAlert bottomAlert;

    @Override
    public void onStatusChanged(String status, Boolean isRunning)
    {
        // TODO: Implement this method
		if (OreoService.isRunning)
		{
			start.setText("Disconnect");
			passW.showPasswordVisibilityIndicator(false);
			serverTypeSpin.setEnabled(false);
			serverSpin.setEnabled(false);
			userN.setEnabled(false);
			passW.setEnabled(false);
			networkSpin.setEnabled(false);
			if (OreoService.isSSHRunning)
			{	
				showSnack("Connected Successfully, Enjoy!😊");
			}/*else{
			 status.setText("Connecting...");
			 }*/
		}
		else
		{
			passW.showPasswordVisibilityIndicator(true);
			serverTypeSpin.setEnabled(true);
			serverSpin.setEnabled(true);
			userN.setEnabled(true);
			passW.setEnabled(true);
			if (sp.getBoolean("custom_payload_key", false))
			{
				networkSpin.setEnabled(false);
			}
			else
			{
				networkSpin.setEnabled(true);
			}
			start.setText("Connect");
			MainActivity.easyFlip.letFlip(1);
			showSnack("Disconnected ! 🙁");
		}
		onLogReceived(status);
    }

    @Override
    public void onLogReceived(String logString)
    {
        // TODO: Implement this method

    }
	@Override
    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setHasOptionsMenu(true);
		new ApplicationBase().init(getActivity());
		db = new DataBaseHelper(getActivity());
		utils = ApplicationBase.getUtils();
		sp = ApplicationBase.getSharedPreferences();
		defsp = ApplicationBase.getDefSharedPreferences();
        OreoService.addOnStatusChangedListener(this);
	}

	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
   		mView = inflater.inflate(R.layout.fragment_home, container, false);
	    //bottomAlert = new BottomSheetAlert(getActivity(), (LinearLayout) mView.findViewById(R.id.homeLayout));
        serverTypeLayout = (LinearLayout) mView.findViewById(R.id.serverTypeSpinCardView);
		serverTypeSpin = (Spinner) mView.findViewById(R.id.serverTypeSpin);
	    serverSpin = (Spinner) mView.findViewById(R.id.serverSpin);
		networkSpin = (Spinner) mView.findViewById(R.id.networkSpin);
		serverTypeList.add("PREMIUM");
		serverTypeList.add("VIP");
		serverTypeList.add("PRIVATE");
		serverTypeSpin.setAdapter(new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_dropdown_item, serverTypeList));
		try
		{
			serverTypeSpin.setSelection(sp.getInt("ServerTypeSpin", 0));
		}
		catch (Exception e)
		{

		}

		serverTypeSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

				@Override
				public void onItemSelected(AdapterView<?> p1, View p2, final int position, long p4)
				{
					// TODO: Implement this method
					sp.edit().putInt("ServerTypeSpin", position).commit();
					if(!sp.getBoolean("Categorie", false)){
						serverList.clear();
						serverList = utils.parseServer(serverList, db.getData(), position);
						serverAdapt = new SpinnerAdapter(getActivity(), serverList);
						serverSpin.setAdapter(serverAdapt);
						serverSpin.setSelection(sp.getInt("ServerSpin" + position, 0));
						serverSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
								@Override
								public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
								{
									// TODO: Implement this method
									try
									{
										sp.edit().putInt("ServerSpin" + sp.getInt("ServerTypeSpin", 0), p3).commit();
										utils.parseSelectedServer(p3, db.getData());
									}
									catch (Exception e)
									{LogFragment.addLog(e.getMessage());}
								}

								@Override
								public void onNothingSelected(AdapterView<?> p1)
								{
									// TODO: Implement this method
								}
							});
					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> p1)
				{
					// TODO: Implement this method
				}
			});
		if(sp.getBoolean("Categorie", false)){
			serverList.clear();
			serverList = utils.parseServer(serverList, db.getData(), 0);
			serverAdapt = new SpinnerAdapter(getActivity(), serverList);
			serverSpin.setAdapter(serverAdapt);
			serverSpin.setSelection(sp.getInt("ServerSpin0", 0));
			serverSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
					@Override
					public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
					{
						// TODO: Implement this method
						try
						{
							sp.edit().putInt("ServerSpin0", p3).commit();
							utils.parseSelectedServer(p3, db.getData());
						}
						catch (Exception e)
						{LogFragment.addLog(e.getMessage());}
					}

					@Override
					public void onNothingSelected(AdapterView<?> p1)
					{
						// TODO: Implement this method
					}
				});
		}

		Vpnmod.clear();
		if (sp.getInt("VPNMod", R.id.mode_1) == R.id.mode_1)
		{
			Vpnmod = HomeFragment.utils.parseNetworkSSH(HomeFragment.networkList, db.getData());
		}
		else
		{
			Vpnmod = HomeFragment.utils.parseNetworkSSL(HomeFragment.networkList, db.getData());
		}
		networkAdapt = new NetworkAdapter(getActivity(),Vpnmod);
	// networkAdapt = new ArrayAdapter(getActivity(),android.R.layout.simple_spinner_dropdown_item,Vpnmod);
		networkSpin.setAdapter(networkAdapt);
		networkSpin.setSelection(sp.getInt("NetworkSpin" + sp.getInt("VPNMod", R.id.mode_1), 0));
		networkSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
				@Override
				public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
				{
					// TODO: Implement this method
					sp.edit().putInt("NetworkSpin" + sp.getInt("VPNMod", R.id.mode_1), p3).commit();
					try
					{
						utils.parseSelectedNetwork(p3, db.getData());
					}
					catch (Exception e)
					{
						LogFragment.addLog(e.getMessage());
					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> p1)
				{
					// TODO: Implement this method
				}
			});

        userN = (EditText) mView.findViewById(R.id.edUsername);
		userN.setText(sp.getString("xUser", ""));
		userN.addTextChangedListener(new TextWatcher(){
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
					sp.edit().putString("xUser", p1.toString()).commit();
				}
			});

		passW = (MaterialEditText) mView.findViewById(R.id.edPassword);
		passW.setText(sp.getString("xPass", ""));
		passW.addTextChangedListener(new TextWatcher(){
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
					// TODO: Implement this method
				}

				@Override
				public void afterTextChanged(Editable p1)
				{
					// TODO: Implement this method
					sp.edit().putString("xPass", p1.toString()).commit();
				}
			});
		start = (Button) mView.findViewById(R.id.switchButton);
		start.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					//showSnack(utils.getPayload());
					if (OreoService.isRunning)
                    {
						startStop(false);
						
						//getActivity().stopService(intent);
					}
                    else
                    {
                        if (sp.getString("xUser", "").isEmpty())
						{
                            showSnack("Username and Password Empty!");
                        }else if(sp.getString("xPass", "").isEmpty()){
							showSnack("Username and Password Empty!");
						}else if (isNetworkAvailable(getActivity()))
                        {
                            Intent prepare = VpnService.prepare(getActivity());
                            if (prepare != null)
                            {
                                startActivityForResult(prepare, 0);
                            }
                            else
                            {
                                onActivityResult(0, -1, null);
                            }
                        }
                        else
                        {
                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
							alertDialogBuilder.setView(R.layout.no_internet);
							alertDialogBuilder.setPositiveButton("ok", null);
							alertDialogBuilder.setCancelable(true);
							AlertDialog alertDialog = alertDialogBuilder.create();
							alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation_1;
							alertDialog.show();
                        }
					}
				}
			});
			
		if(sp.getBoolean("Categorie", false)){
			serverTypeLayout.setVisibility(View.GONE);
		}else{
			serverTypeLayout.setVisibility(View.VISIBLE);
		}
		return mView;
	}

	@Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == android.app.Activity.RESULT_OK)
        {
            try
            {
				startStop(true);
			}
            catch (Exception e)
            {
				//Log.d(TAG, e.getMessage());
			}
        }
    }

	

	public static void upRefresh() {
		if(sp.getBoolean("Categorie", false)){
			serverTypeLayout.setVisibility(View.GONE);
		}else{
			serverTypeLayout.setVisibility(View.VISIBLE);
		}
		serverList.clear();
		serverList = utils.parseServer(serverList, db.getData(), sp.getInt("ServerTypeSpin", 0));
		serverAdapt.notifyDataSetChanged();
		Vpnmod.clear();
		if (sp.getInt("VPNMod", R.id.mode_1) == R.id.mode_1)
		{
			Vpnmod = HomeFragment.utils.parseNetworkSSH(HomeFragment.networkList, db.getData());
		}
		else
		{
			Vpnmod = HomeFragment.utils.parseNetworkSSL(HomeFragment.networkList, db.getData());
		}
		networkAdapt.notifyDataSetChanged();
	}

	public void startStop(boolean z)
    {
		Intent intent = new Intent(getActivity(), OreoService.class);
		if (z)
        {
			start.setText("Disconnect");
			if(defsp.getBoolean("auto_logs_key", true)) MainActivity.mPager.setCurrentItem(1, true);
			if(defsp.getBoolean("auto_clear_logs_key", true)) LogFragment.clear();
			passW.showPasswordVisibilityIndicator(false);
			MainActivity.easyFlip.letFlip(0);
			serverTypeSpin.setEnabled(false);
			serverSpin.setEnabled(false);
			userN.setEnabled(false);
			passW.setEnabled(false);
			networkSpin.setEnabled(false);
            getActivity().startService(intent.setAction("START"));
		}
        else
        {
			start.setText("Connect");
			passW.showPasswordVisibilityIndicator(true);
			MainActivity.easyFlip.letFlip(1);
			serverTypeSpin.setEnabled(true);
			serverSpin.setEnabled(true);
			userN.setEnabled(true);
			passW.setEnabled(true);
			//networkTypeSpin.setEnabled(true);
			if (sp.getInt("NetworkTypeSpin", 0) == 2)
			{
				networkSpin.setEnabled(false);
			}
			else if (sp.getBoolean("custom_payload_key", false))
			{
				networkSpin.setEnabled(false);
			}
			else
			{
				networkSpin.setEnabled(true);
			}
            getActivity().stopService(intent.setAction("STOP"));
		}
	}

	void showSnack(String message)
	{
		Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
	}

    public boolean isNetworkAvailable(Context context)
    {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}

    @Override
    public void onPause()
	{
        // This method should be called in the parent Activity's onPause() method.
		if (adView != null) {
		 adView.pause();
		 }
        super.onPause();
    }

    @Override
    public void onDestroy()
	{
        // This method should be called in the parent Activity's onDestroy() method.
        if (adView != null) {
		 adView.destroy();
		 }
        super.onDestroy();
    }
    @Override
    public void onResume()
    {
        // TODO: Implement this method
        super.onResume();
        if (adView != null) {
		 adView.resume();
		 }
        update_ui();
    }

	void update_ui() {
		if (OreoService.isRunning)
		{
			start.setText("Disconnect");
			passW.showPasswordVisibilityIndicator(false);
			MainActivity.easyFlip.letFlip(0);
			serverTypeSpin.setEnabled(false);
			serverSpin.setEnabled(false);
			userN.setEnabled(false);
			passW.setEnabled(false);
			networkSpin.setEnabled(false);
		}
		else
		{
			passW.showPasswordVisibilityIndicator(true);
			MainActivity.easyFlip.letFlip(1);
			serverTypeSpin.setEnabled(true);
			serverSpin.setEnabled(true);
			userN.setEnabled(true);
			passW.setEnabled(true);
			//networkTypeSpin.setEnabled(true);
			if (sp.getInt("NetworkTypeSpin", 0) == 2)
			{
				networkSpin.setEnabled(false);
			}
			else if (sp.getBoolean("custom_payload_key", false))
			{
				networkSpin.setEnabled(false);
			}
			else
			{
				networkSpin.setEnabled(true);
			}
			start.setText("Connect");
		}
	}

	@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater)
    {
		menuInflater.inflate(R.menu.menu_main, menu);
        super.onCreateOptionsMenu(menu, menuInflater);
    }

	@Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
		//String data = LogView.arrayList.toString().replace(", ", "\n");
		switch (menuItem.getItemId())
        {
			case R.id.update:
				new AlertDialog.Builder(getActivity())
                    .setCancelable(false)
                    .setTitle("Config Updater")
                    .setMessage(" Online Update - requires internet connection.")
                    .setPositiveButton("Config update", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface p1, int p2)
                        {
                            // TODO: Implement this method
                            new UpdateAsync(getActivity(), new UpdateAsync.Listener() {
									@Override
									public void onCompleted(String config)
									{
										// TODO: Implement this method
										try
										{
											JSONObject obj = new JSONObject(XxTea.decryptBase64StringToString(config, "123456"));
											if (obj.getInt("UpdateVersion") == sp.getInt("CurrentConfigVersion", 0))
											{
												AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
												alertDialogBuilder.setView(R.layout.updated);
												alertDialogBuilder.setPositiveButton("ok", null);
												alertDialogBuilder.setCancelable(true);
												AlertDialog alertDialog = alertDialogBuilder.create();
												alertDialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation_1;
												alertDialog.show();
											}
											else
											{
												db.updateData("1", config);
												sp.edit().putInt("ServerSpin0", 0).commit();
												sp.edit().putInt("ServerSpin1", 0).commit();
												sp.edit().putInt("NetworkSpin0", 0).commit();
												sp.edit().putInt("NetworkSpin1", 0).commit();
												sp.edit().putBoolean("Categorie", obj.getBoolean("Categories")).commit();
												sp.edit().putString("DefSquidPort", obj.getString("DefSquidPort")).commit();
												defsp.edit().putString("custom_update_url", obj.getString("DefUpdateURL")).commit();
												sp.edit().putString("ContactSupport", obj.getString("ContactSupport")).commit();
												AlertDialog.Builder adb = new AlertDialog.Builder(getActivity())
													.setCancelable(false)
													.setTitle("What's New?");
												StringBuffer sb = new StringBuffer();
												JSONArray jarr = obj.getJSONArray("ReleaseNotes");
												for (int i=0;i < jarr.length();i++)
												{
													sb.append(jarr.getString(i) + "\n");
												}
												adb.setMessage(sb.toString())
													.setPositiveButton("Update", new DialogInterface.OnClickListener(){
														@Override
														public void onClick(DialogInterface p1, int p2)
														{
															// TODO: Implement this method
															if (OreoService.isRunning)
															{
																getActivity().stopService(new Intent(getActivity(), OreoService.class));
															}
															HomeFragment.upRefresh();
															//mRestart(mContext);
														}
													})
													.setNegativeButton("Later", null)
													.create().show();
												sp.edit().putInt("CurrentConfigVersion", obj.getInt("UpdateVersion")).commit();
											}
										}
										catch (Exception e)
										{
											LogFragment.addLog(e.getMessage());
										}
									}

									@Override
									public void onCancelled()
									{
										// TODO: Implement this method
									}

									@Override
									public void onException(String ex)
									{
										// TODO: Implement this method
										Toast.makeText(getActivity(), "Something went wrong, Please try again.", 0).show();
									}
								}).execute();
                        }})
						.setNegativeButton("OFFLINE", new DialogInterface.OnClickListener(){
						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							// TODO: Implement this method
							dialog.show();
						}
					})
                    .setNegativeButton("App update", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface p1, int p2)
                        {
                        }
                    }).setNeutralButton("Cancel", null)
                    .create().show();
				return true;
			default:
				return super.onOptionsItemSelected(menuItem);
        }
    }
	}
