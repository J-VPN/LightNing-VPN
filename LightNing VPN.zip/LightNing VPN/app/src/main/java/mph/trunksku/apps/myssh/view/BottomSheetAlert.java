package mph.trunksku.apps.myssh.view;

import android.content.*;
import android.support.design.widget.*;
import android.view.*;
import android.widget.*;
import net.finalfixvpn.ml2.*;

public class BottomSheetAlert
{
    private BottomSheetBehavior behavior;

    private View inflate;
    public BottomSheetAlert(Context c, LinearLayout v){
        LayoutInflater inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflate = inflater.inflate(R.layout.layout_bottom_sheet_alert, (ViewGroup) null);
        behavior = BottomSheetBehavior.from(inflate);
        v.addView(inflate);
    }
    
    public BottomSheetAlert setMessage(String msg){
        ((TextView) inflate.findViewById(R.id.message)).setText(msg);
        return this;
    }
    
    public BottomSheetAlert setAction(View.OnClickListener click){
        ((Button) inflate.findViewById(R.id.buttonClick)).setOnClickListener(click);
        return this;
    }
    
    public void show(){
        behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
    }
    
    public void hide(){
        behavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
    }
}
