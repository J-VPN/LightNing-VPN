package mph.trunksku.apps.myssh;
import android.os.*;
import android.support.v7.app.*;
import net.finalfixvpn.ml2.*;

public class AboutActivity extends AppCompatActivity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_home);
	}
	
}
