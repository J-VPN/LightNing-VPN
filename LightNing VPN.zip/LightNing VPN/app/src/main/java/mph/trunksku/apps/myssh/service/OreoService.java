package mph.trunksku.apps.myssh.service;
import android.annotation.*;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import net.finalfixvpn.ml2.*;
import com.trilead.ssh2.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import mph.trunksku.apps.myssh.*;
import mph.trunksku.apps.myssh.core.*;
import mph.trunksku.apps.myssh.fragment.*;
import mph.trunksku.apps.myssh.model.*;
import mph.trunksku.apps.myssh.util.*;
import mph.trunksku.apps.myssh.view.*;

public class OreoService extends Service implements InteractiveCallback
{

	private Timer updateTimer;

	private NotificationManager nm;

	private SharedPreferences dsp;

	public static boolean isRunning = false;
	public static boolean isSSHRunning = false;
	public static final String NOTIFICATION_CHANNEL_BG_ID = "sshvpn_bg";
    public static final String NOTIFICATION_CHANNEL_NEWSTATUS_ID = "magicph_innovation_inc";

	private static final String AUTH_KEYBOARDINTERACTIVE = "keyboard-interactive";
    private static final String AUTH_PASSWORD = "password";
    private static final int AUTH_TRIES = 1;
    private final int MSG_CONNECTED = AUTH_TRIES;
    private final int MSG_CONNECTING = 3;
    private final int MSG_FINISH = 2;
    private final String TAG = "SSH Tunnel";
    private Connection connection;
	private Handler m_Handler=new Handler();
    private static ConcurrentHashMap<StatusChangeListener, Object> m_OnStatusChangedListeners=new ConcurrentHashMap<StatusChangeListener, Object>();
	private LocalPortForwarder dnsForwarder;
	private DynamicPortForwarder socksPortForwarder;
	private Config ssh;
	private ServerSocket listen_proxy;
	public  Socket input;
	public static Socket output;

	private VpnService eVpnService;

	private DnsProxy dnsProxy;
	//private UUID mUuid;
    private String lastChannel;
	private SharedPreferences sp;
	private static final int NOTIFICATION_ID = 1642;
	private Notification.Builder mNotifyBuilder;
	private final String CHANNEL_ID = "mphssh_channel_1";
    private final String CHANNEL_NAME = "mphssh_channel";
	private int listen_port = 8083;

	Thread dataThread;

	private Utility sslutil;
	@Override
	public IBinder onBind(Intent p1)
	{
		// TODO: Implement this method
		return null;
	}

	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
		sslutil = new Utility(this);
		sp = ApplicationBase.getSharedPreferences();
		dsp = ApplicationBase.getDefSharedPreferences();
		ssh = ApplicationBase.getUtils();
		nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		// TODO: Implement this method
		String action = intent.getAction();
        switch (action)
		{
			case "START":
				
				isRunning = true;
				dataThread = new Thread(new MyThreadClass(startId));
				dataThread.setName("showNotification");
				dataThread.start();
				if (!StoredData.isSetData)
				{
					StoredData.setZero();
				}
				if(sp.getInt("ModeVersionSpin", 0) == 0){
					runHttp();
				}else{
					sslutil.setupConfig(ssh.getSSHHost(), ssh.getSSHPort(), ssh.getPayload());
					sslutil.start();
					oreo.sendEmptyMessage(1);
				}
				break;
			case "STOP":
				//isRunning = false;
				stop_notification();
				onDestroy();
				stopSelf();
				break;
		}
		return 1;
	}

	@Override
	public void onDestroy()
	{
		// TODO: Implement this method
		super.onDestroy();
		isRunning = false;
		/*if(sp.getInt("NetworkTypeSpin", 0) == 2){
		 oreo.sendEmptyMessage(0);
		 }else{*/
		if(sp.getInt("ModeVersionSpin", 0) == 0){
			stopHttp();
		}else{
			sslutil.stop();
			oreo.sendEmptyMessage(0);
		}
		//}

	}

	public boolean doVpnProtect(Socket socket)
	{
        if (eVpnService == null)
		{
            eVpnService = new VpnService();
        }
        if (eVpnService.protect(socket))
		{
           // sshMsg("Socket has protected");
            return true;
        }
       // sshMsg("Socket has not protected");
        return false;
    }




	public void runHttp()
	{
		new Thread(new Runnable() {
				public void run()
				{
					try
					{
						listen_proxy = new ServerSocket(listen_port);
						listen_proxy.setReuseAddress(true);
						oreo.sendEmptyMessage(1);
						while (true)
						{
							input = listen_proxy.accept();
							sshMsg("Response from local port: " + input.getPort());
							input.setSoTimeout(0);
							if (sp.getInt("VPNMod", R.id.mode_1) == R.id.mode_1)
							{
								output = new HTTPSupport(input).inject();
							}
							else
							{
								output = new SSLSupport(input).socket();
							}
							if (input != null)
							{
								input.setKeepAlive(true);
							}
							if (output != null)
							{
								output.setKeepAlive(true);
							}
							if (output == null)
							{
								input.close();
							}
							else if (output.isConnected())
							{ 
								doVpnProtect(output);
								if (sp.getInt("VPNMod", R.id.mode_1) == R.id.mode_1)
								{
								 	HTTPThread.connect(input, output);
								}
								else
								{
									SSLThread.connect(input, output);
								}
							}
						}
					}
					catch (Exception e)
					{
						//sshMsg(e.getMessage());
					}
				}
			}).start();
	}

	public void stopHttp()
	{
		synchronized (this)
		{
			oreo.sendEmptyMessage(0);
			if (this.listen_proxy != null)
			{
				try
				{
					this.listen_proxy.close();
				}
				catch (Exception e)
				{
				}
			}
			if (this.input != null)
			{
				try
				{
					this.input.close();
				}
				catch (IOException e2)
				{
					//addLog(e2.getMessage());
				}
			}
			if (this.output != null)
			{
				try
				{
					this.output.close();
				}
				catch (Exception e3)
				{
				}
			}
		}
	}

	private Handler oreo = new Handler() {
        public void handleMessage(Message msg)
		{
			if (msg.what != 1)
			{
				new Thread(new Runnable() {
						public void run()
						{
							onDisconnect();
						}
					}).start();
			}
			else
			{
				status_handler.sendEmptyMessage(3);
				runService();
			}
        }
    };

	public boolean runCommand(String command)
	{
		java.lang.Process process = null;
		try
		{
			process = Runtime.getRuntime().exec(command);
			process.waitFor();
		}
		catch (Exception e)
		{
			sshMsg(e.getMessage());
			return false;
		}
		finally
		{
			try
			{
				process.destroy();
			}
			catch (Exception e)
			{
				// nothing
			}
		}
		return true;
	}

    @SuppressLint({"HandlerLeak"})
    final Handler status_handler = new Handler() {
        public void handleMessage(Message msg)
		{
            switch (msg.what)
			{
                case MSG_CONNECTED:
					isSSHRunning = true;
					onStatusChanged("Connected", true);
					update_notification_event(R.drawable.ic_cloud_check, "Connected");
					break;
                case MSG_FINISH:
					onStatusChanged("Disconnected", false);
					isSSHRunning = false;
					update_notification_event(R.drawable.ic_cloud_outline_off, "Disconnected");
					break;
                case MSG_CONNECTING:
					onStatusChanged("Connecting...", false);
                    update_notification_event(R.drawable.ic_cloud_circle, "Connecting...");
                    writeLog("Connecting...");
                    break;

            }
            super.handleMessage(msg);
        }
    };

	final class MyThreadClass implements Runnable
	{

        int service_id;

        MyThreadClass(int service_id)
		{
            this.service_id = service_id;

        }

        @Override
        public void run()
		{
            int i = 0;
            synchronized (this)
			{
                while (dataThread.getName() == "showNotification")
				{
                    //  Log.e("insidebroadcast", Integer.toString(service_id) + " " + Integer.toString(i));
                    getData();
                    try
					{
                        wait(1000);
                        i++;
                    }
					catch (InterruptedException e)
					{
                        sshMsg(e.getMessage());
                    }

                }
                //stopSelf(service_id);
            }

        }
    }

	public void getData()
	{

        List<Long> allData;

        //if (!network_status.equals("no_connection")) {
        //receiveData = RetrieveData.findData();
        allData = RetrieveData.findData();

        Long mDownload, mUpload;
		long upload = DataTransferGraph.upload;
		long download = DataTransferGraph.access$1;


        mDownload = allData.get(0);
        mUpload = allData.get(1);

        //receiveData = mDownload + mUpload;
        //storedData(mDownload, mUpload);
		storedData(download, upload);
    }

	public void storedData(Long mDownload, Long mUpload)
	{

        StoredData.downloadSpeed = mDownload;
        StoredData.uploadSpeed = mUpload;

        if (StoredData.isSetData)
		{
            StoredData.downloadList.remove(0);
            StoredData.uploadList.remove(0);

            StoredData.downloadList.add(mDownload);
            StoredData.uploadList.add(mUpload);
        }

		// Log.e("storeddata","test "+toString().valueOf(StoredData.downloadList.size()));

    }

	public static void addOnStatusChangedListener(StatusChangeListener listener)
	{
        if (!m_OnStatusChangedListeners.containsKey(listener))
		{
            m_OnStatusChangedListeners.put(listener, 1);
        }
    }

    public static void removeOnStatusChangedListener(StatusChangeListener listener)
	{
        if (m_OnStatusChangedListeners.containsKey(listener))
		{
            m_OnStatusChangedListeners.remove(listener);
        }
    }

    private void onStatusChanged(final String status, final boolean isRunning)
	{
        m_Handler.post(new Runnable() {
				@Override
				public void run()
				{
					for (Map.Entry<StatusChangeListener, Object> entry : m_OnStatusChangedListeners.entrySet())
					{
						entry.getKey().onStatusChanged(status, isRunning);
					}
				}
			});
	}

    public void writeLog(final String logs)
	{
        m_Handler.post(new Runnable() {
                @Override
                public void run()
				{
                    for (Map.Entry<StatusChangeListener, Object> entry : m_OnStatusChangedListeners.entrySet())
					{
                        entry.getKey().onLogReceived(logs);
                    }
                }
            });
	}

    private void authenticate()
	{
        try
		{
            if (connection.authenticateWithNone(ssh.getSshUsername()))
			{
                sshMsg("Authenticate with none");
                return;
            }
			if (connection.isAuthMethodAvailable(ssh.getSshUsername(), "password"))
			{
                sshMsg("Username: " + ssh.getSshUsername());
                if (connection.authenticateWithPassword(ssh.getSshUsername(), ssh.getSshPassword()))
				{
                    sshMsg("Authenticate with password");
                    return;
                }
            }
			if (connection.isAuthMethodAvailable(ssh.getSshUsername(), "keyboard-interactive"))
			{
                if (connection.authenticateWithKeyboardInteractive(ssh.getSshUsername(), this))
                    return;
            }
        }
		catch (Exception e)
		{
            sshMsg("Something wen't wrong in authentication.");
        }
    }


    public boolean connect()
	{
        try
		{
            connection = new Connection(ssh.getSSHHost(), Integer.parseInt(ssh.getSSHPort()));
			connection.setProxyData(new HTTPProxyData("127.0.0.1", listen_port));
            //connection.setCompression(true);
            connection.addConnectionMonitor(new Monitor());
            connection.connect(new eServerHostKeyVerifier(), 10 * 1000, 20 * 1000);
            //connected = true;
			int tries = 0;
            while (!connection.isAuthenticationComplete() && tries++ < 1)
			{
                authenticate();
                Thread.sleep(1000);
            }
			if (connection.isAuthenticationComplete())
			{
                return enableSocksForward();
            }
        }
		catch (Exception e)
		{
            //sshMsg("[Error] " + e.getLocalizedMessage());
            return false;
        }

        sshMsg("Invalid Username and Password");
        return false;
    }


	class Monitor implements ConnectionMonitor
    {
        @Override
        public void connectionLost(Throwable arg0)
		{
			vpn_handler(false);
		}
    }

	public class eServerHostKeyVerifier implements ServerHostKeyVerifier
    {
		@Override
		public boolean verifyServerHostKey(String hostname, int port, String keyAlgorithm, byte[] hostKey) throws Exception
		{
			String createHexFingerprint = KnownHosts.createHexFingerprint(keyAlgorithm, hostKey);
			String createHashedHostname = KnownHosts.createHashedHostname(hostname);
			String createBubblebabbleFingerprint = KnownHosts.createBubblebabbleFingerprint(keyAlgorithm, hostKey);
			sshMsg(new StringBuffer().append("<b>Hex Fingerprint:</b> ").append(createHexFingerprint).toString());
			sshMsg(new StringBuffer().append("<b>Hashed Hostname:</b> ").append(createHashedHostname).toString());
			sshMsg(new StringBuffer().append("<b>Bubble Babble  Fingerprint:</b> ").append(createBubblebabbleFingerprint).toString());
			return true;
		}
	}


    private boolean enableSocksForward()
	{
        try
		{
			//Utils.updateDnsResolvers(this);
			dnsForwarder = connection.createLocalPortForwarder(8053, "www.google.com", 80);
			//sshMsg("Local Port Forwarding started at port: "+ssh.getLocalPort());

			socksPortForwarder = connection.createDynamicPortForwarder(1080);//new InetSocketAddress("127.0.0.1", KPNContext.getSshSocks()));
			//sshMsg("Dynamic Port Forwarding started at port: "+ssh.getDynamicPort());

            sshMsg("Forward Successful");
            //connection.ping();
            return true;
        }
		catch (Exception e)
		{
            sshMsg(e.toString());
            return false;
        }
    }



    private void onDisconnect()
	{
        try
		{
			if (socksPortForwarder != null)
			{
                socksPortForwarder.close();
                socksPortForwarder = null;
            }
        }
		catch (Exception e)
		{
        }
		try
		{
            if (dnsForwarder != null)
			{
                dnsForwarder.close();
                dnsForwarder = null;
            }
        }
		catch (Exception e2)
		{
        }
        if (connection != null)
		{
            connection.close();
            connection = null;
        }
		//sshMsg("SSH Disconnected");
		//flushDNS();

    }



	

    private void update_notification_event(int icon, String str)
	{
		if (dsp.getBoolean("show_notification", true))
		{
			if (this.mNotifyBuilder != null){
				this.mNotifyBuilder = new Notification.Builder(this);
				this.mNotifyBuilder.setSmallIcon(R.drawable.main_icon);
				this.mNotifyBuilder.setContentText(str);
				this.mNotifyBuilder.setContentTitle("PHIEXPE VPN");
				this.mNotifyBuilder.setOnlyAlertOnce(true);
				this.mNotifyBuilder.setWhen(new Date().getTime());
				this.mNotifyBuilder.setOngoing(true).build();
				startForeground(NOTIFICATION_ID, this.mNotifyBuilder.getNotification());
				if(str.equals("Connected")){
					initSoundVibrate(this.mNotifyBuilder);
				}
				nm.notify(123, this.mNotifyBuilder.getNotification());
				startForeground(123, this.mNotifyBuilder.getNotification());
				/*if (str.equals("Connected"))
				{
					ByteNotification();
				}*/
			}
		}
    }

	public void initSoundVibrate(Notification.Builder nb)
	{
		try
		{
			if (dsp.getBoolean("sound_notification", true))
	//			nb.setSound(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.mph_love));
			if (dsp.getBoolean("vibrate_notification", true))
				nb.setVibrate(new long[] {0, 300, 100, 300});
		}
		catch (Exception e)
		{
			sshMsg("Something wen't wrong in notification sound and vibrate.");
		}
	}

	public synchronized void ByteNotification()
	{
	    updateTimer = new Timer();
        updateTimer.scheduleAtFixedRate(new TimerTask() {
				public void run()
				{
					synchronized (OreoService.this)
					{
						long upload = DataTransferGraph.GraphData.xup() + DataTransferGraph.GraphData.getTotalOverheadBytesSnd();
						long download = DataTransferGraph.GraphData.xdown() + DataTransferGraph.GraphData.getTotalOverheadBytesRcv();
						long sdown = DataTransferGraph.download;
						long sup = DataTransferGraph.upload;
						mNotifyBuilder.setContentText("↓" + DataTransferGraph.Count(sdown, true) + " / " + DataTransferGraph.Count(download, false) + " ↑" + DataTransferGraph.Count(sup, true) + " / " + DataTransferGraph.Count(upload, false));
						mNotifyBuilder.setOnlyAlertOnce(true);
						nm.notify(123, mNotifyBuilder.getNotification());
						startForeground(123, mNotifyBuilder.getNotification());
					}
				}
			}, 0, 1000);
	}

    private void stop_notification()
	{
		if (dsp.getBoolean("show_notification", true))
		{
			if (this.mNotifyBuilder != null)
			{
				if (updateTimer != null)
				{
					updateTimer.cancel();
					updateTimer = null;
				}
				this.mNotifyBuilder = null;
				nm.cancel(123);
				stopForeground(true);
			}
		}
    }

	private void vpn_handler(boolean on)
	{
		try
		{
			if (on)
			{
				Intent intent = new Intent(OreoService.this, DemoVPNService.class);
				startService(intent.setAction("START"));
			}
			else
			{
				Intent intent = new Intent(OreoService.this, DemoVPNService.class);
				startService(intent.setAction("STOP"));
			}
		}
		catch (Exception e)
		{
			sshMsg("Something wen't wrong in vpn service.");
		}
	}

    private void runService()
	{
        new Thread(new Runnable() {
				public void run()
				{
					status_handler.sendEmptyMessage(3);
					if (connect())
					{
						sshMsg("SSH Connected");
						status_handler.sendEmptyMessage(AUTH_TRIES);
						vpn_handler(true);
						return;
					}
					status_handler.sendEmptyMessage(2);
					onDestroy();
				}
			}).start();
    }

	@SuppressLint({"DefaultLocale"})
    public String[] replyToChallenge(String name, String instruction, int numPrompts, String[] prompt, boolean[] echo) throws Exception
	{
        String[] responses = new String[numPrompts];
        for (int i = 0; i < numPrompts; i += AUTH_TRIES)
		{
            if (prompt[i].toLowerCase().contains(AUTH_PASSWORD))
			{
                responses[i] = ssh.getSshPassword();
            }
        }
        return responses;
    }

    private void sshMsg(String msg)
	{
        LogFragment.addLog(msg);
    }
}
