package mph.trunksku.apps.myssh.view;
import android.content.*;
import android.support.v7.app.*;
import android.view.*;
import android.widget.*;
import net.finalfixvpn.ml2.*;
import java.util.*;
import mph.trunksku.apps.myssh.*;
import mph.trunksku.apps.myssh.db.*;
import mph.trunksku.apps.myssh.fragment.*;
import mph.trunksku.apps.myssh.adapter.*;

public class VPNModeDialog
{
	private AlertDialog.Builder adb;
	private LayoutInflater inflater;
	private RadioGroup vpnmode;
	private SharedPreferences sp;
	private DataBaseHelper db;
	private Spinner vpnmodeVersion;
	public ArrayList<String> modeTypeList = new ArrayList();
	
	public VPNModeDialog(final Context c){
		db = new DataBaseHelper(c);
		sp = ApplicationBase.getSharedPreferences();
		inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	    View inflate = inflater.inflate(R.layout.layout_vpnmode, (ViewGroup) null);
		vpnmodeVersion = (Spinner) inflate.findViewById(R.id.vpn_mode_version);
		modeTypeList.add("SSL V1");
		modeTypeList.add("SSL V2");
		vpnmodeVersion.setAdapter(new ArrayAdapter(c, android.R.layout.simple_spinner_dropdown_item, modeTypeList));
		vpnmodeVersion.setSelection(sp.getInt("ModeVersionSpin", 0));
		vpnmodeVersion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
				@Override
				public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
				{
					// TODO: Implement this method
					sp.edit().putInt("ModeVersionSpin", p3).commit();
				}

				@Override
				public void onNothingSelected(AdapterView<?> p1)
				{
					// TODO: Implement this method
				}
			});
		vpnmodeVersion.setVisibility(View.GONE);

		vpnmode = (RadioGroup) inflate.findViewById(R.id.mode_group);
		vpnmode.check(sp.getInt("VPNMod", R.id.mode_1));
		vpnmode.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(RadioGroup p1, int p2)
				{
				/*	// TODO: Implement this method
					if(p2 == R.id.mode_1) {
						vpnmodeVersion.setVisibility(View.GONE);
					}else{
						vpnmodeVersion.setVisibility(View.VISIBLE);
					} */
				}
			});
		adb = new AlertDialog.Builder(c);
	    adb.setTitle("VPN MODE");
	    adb.setMessage("Select VPN Mode");
		adb.setView(inflate, 40, 0, 40, 0);
		adb.setPositiveButton("SAVE", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					// TODO: Implement this method
					sp.edit().putInt("VPNMod", vpnmode.getCheckedRadioButtonId()).commit();
					if(sp.getBoolean("custom_payload_key", false)){
						//networkSpin.setEnabled(false);
					}
					HomeFragment.Vpnmod.clear();
					if(sp.getInt("VPNMod", R.id.mode_1) == R.id.mode_1){
						HomeFragment.Vpnmod =HomeFragment.utils.parseNetworkSSH(HomeFragment.networkList, db.getData());
					}else{
						HomeFragment.Vpnmod =HomeFragment.utils.parseNetworkSSL(HomeFragment.networkList, db.getData());
					}
					HomeFragment.networkSpin.setAdapter(new NetworkAdapter(c,HomeFragment.Vpnmod));
					
				}
			});
		adb.setNegativeButton("CANCEL", null);
	}
	
	public void show(){
		adb.create().show();
	}
}
