package mph.trunksku.apps.myssh;

import android.view.ViewGroup;

class BottomNavigationAnimationHelperBase {
    void beginDelayedTransition(ViewGroup view) {
        // Do nothing.
    }
}
