package mph.trunksku.apps.myssh.adapter;

import android.content.*;
import android.widget.*;
import java.util.*;
import net.finalfixvpn.ml2.*;
import android.view.*;

public class NetworkAdapter extends ArrayAdapter<String>
{
	public NetworkAdapter (Context con, ArrayList <String> list){
		super (con, R.layout.network_item, list);	
	}
	@Override
	public int getViewTypeCount()
	{
		// TODO: Implement this method
		return super.getViewTypeCount();
	}
	@Override
	public String getItem(int position)
	{
		// TODO: Implement this method
		return super.getItem(position);
	}
	@Override
	public View getDropDownView(int position, View convertView, ViewGroup parent)
	{
		// TODO: Implement this method
		//return super.getDropDownView(position, convertView, parent);
		return view(position, convertView, parent);
		}
	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		// TODO: Implement this method
		return view(position, convertView, parent);
	}
	private View view (int position, View convertView, ViewGroup parent){
	View v = LayoutInflater.from(getContext()).inflate(R.layout.network_item,parent,false);	
	TextView tv=(TextView) v. findViewById(R.id.network_txt);
	ImageView img = (ImageView) v.findViewById(R.id.network_img);
		String name = getItem(position);
		tv.setText(name);
		if (name.contains("Globe Network")){
			img.setImageResource (R.drawable.globe);
		} else if (name.contains("Talk 'N Text")){
			img.setImageResource (R.drawable.tnt);
		} else if (name.contains("Smart Buddy")){
			img.setImageResource (R.drawable.smart);
		} else if (name.contains("Sun Cellular")){
			img.setImageResource (R.drawable.sun);
		}
	return v;
		}
}
