package mph.trunksku.apps.myssh.util;
import java.util.*;

public class Constraints
{
	public String defrepo = "";

	public static final char defaultUa = 0;

	public static Collection blockApp;
}
