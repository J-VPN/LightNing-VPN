package mph.trunksku.apps.myssh.service;

import android.annotation.*;
import android.content.*;
import android.content.pm.*;
import android.content.res.*;
import android.net.*;
import android.os.*;
import android.preference.*;
import android.system.*;
import android.text.*;
import com.runjva.sourceforge.jsocks.protocol.*;
import com.runjva.sourceforge.jsocks.server.*;
import net.finalfixvpn.ml2.*;
import java.io.*;
import java.math.*;
import java.net.*;
import java.util.*;
import kpn.soft.dev.kpnrevolution.natives.*;
import mph.trunksku.apps.myssh.*;
import mph.trunksku.apps.myssh.core.*;
import mph.trunksku.apps.myssh.logger.*;
import mph.trunksku.apps.myssh.util.*;

import com.runjva.sourceforge.jsocks.protocol.ProxyServer;

public class DemoVPNService extends VpnService implements Runnable
{

    protected static final String TAG = "ki4a";
    public static String FLAG_VPN_START = "START";
    public static String FLAG_VPN_STOP = "STOP";
    private ParcelFileDescriptor mInterface;
    private Thread mThread;
	public static String sSocksProxyLocalhost = ((String) null);
    public static int sSocksProxyServerPort = -1;
    private ProxyServer mSocksProxyServer;

	private SharedPreferences dsp;

	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
		dsp = ApplicationBase.getDefSharedPreferences();
	}

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
	{
		String action = intent.getAction();
        if (action == FLAG_VPN_START)
		{
            addLog("Connecting VPN tunnel");
            // Stop the previous session by interrupting the thread.
            if (mThread != null)
			{
                mThread.interrupt();
            }
            mThread = new Thread(this, "myVPNThread");
            mThread.start();
        }
        else if (action == FLAG_VPN_STOP)
		{
            addLog("Disconnecting VPN tunnel");
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
				stopSocksBypass();
            this.onDestroy();
            stopSelf();
			//addLog(getString(R.string.app_name) + " Disconnected");
        }

        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy()
	{
		// MyLog.i(TAG, "Closing");
		if (OreoService.isRunning)
		{
			stopService(new Intent(this, OreoService.class));
		}
		PdnsD(false);
        if (mThread != null)
		{
            mThread.interrupt();
        }
        if (mInterface != null)
		{
            try
			{
                mInterface.close();
            }
			catch (IOException e)
			{ /* Ignore a close error here */ }
        }
		Tun2Socks.Stop();
    }

    @Override
    public void onRevoke()
	{
        // If vpn was revoked, let's close and destroy everything
        this.onDestroy();
        //Util.reportRevoked(this);
    }

    @Override
    public void run()
	{
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
			startSocksBypass();
        configure();
    }

    private void configure()
    {
        if (mInterface != null)
		{
            addLog("Using the previous interface");
            return;
        }
		  try
		{
			Random random = new Random();
			String address = new StringBuffer().append("10.").append(random.nextInt(256)).append(".").append(random.nextInt(256)).append(".").append(random.nextInt(256)).toString();
            Builder builder = getBuilder();
            builder.setSession(getString(R.string.app_name));
            
            mInterface = builder.establish();

            if (mInterface == null)
			{
                // If we can not connect, let's close and destroy everything
                this.onDestroy();
                //Util.reportDisconnection(this);
            }
			//protect(OreoService.output);
			PdnsD(true);
			Tun2Socks.Start(mInterface.detachFd(), 8192, address, "255.255.255.0", "127.0.0.1:1080", "127.0.0.1:7300", address + ":9395", true);
        }
		catch (Exception e)
		{
            addLog(e.toString());
            this.onDestroy();
			// Util.reportDisconnection(this);
        }
    }

	@TargetApi(21)
    private void allowAllAFFamilies(Builder builder)
	{
        builder.allowFamily(OsConstants.AF_INET);
        builder.allowFamily(OsConstants.AF_INET6);
    }

	@TargetApi(Build.VERSION_CODES.LOLLIPOP)
	private void doLollipopAppRouting(Builder builder) throws Exception
    {    

        ArrayList<TorifiedApp> apps = TorifiedApp.getApps(this, ApplicationBase.getSharedPreferences());

        boolean perAppEnabled = false;

        for (TorifiedApp app : apps)
        {
        	if (app.isTorified() && (!app.getPackageName().equals(getPackageName())))
        	{
        		builder.addAllowedApplication(app.getPackageName());
        		perAppEnabled = true;
        	}

        }

        if (!perAppEnabled)
        	builder.addDisallowedApplication(getPackageName());

    }
	private void startSocksBypass()
	{
        Thread mySocks = new Thread(this) {
			public void run()
			{
                if (sSocksProxyServerPort == -1)
				{
                    try
					{
                        sSocksProxyLocalhost = "127.0.0.1";
                        sSocksProxyServerPort = (int) ((Math.random() * ((double) 1000)) + ((double) 10000));
                    }
					catch (Exception e)
					{
                        //LogZ.e(VPNManager.TAG, "Unable to access localhost", th);
                    }
                }
                if (mSocksProxyServer != null)
				{
                    stopSocksBypass();
                }
                try
				{
                    ServerAuthenticatorNone serverAuthenticatorNone = new ServerAuthenticatorNone((InputStream) null, (OutputStream) null);
					mSocksProxyServer = new ProxyServer(serverAuthenticatorNone);
					mSocksProxyServer.setVpnService(DemoVPNService.this);
                    mSocksProxyServer.start(sSocksProxyServerPort, 5, InetAddress.getLocalHost());
                }
				catch (Exception e2)
				{
                    //LogZ.e(VPNManager.TAG, "error getting host", e2);
                }
            }
        };
        mySocks.start();
    }

    private synchronized void stopSocksBypass()
	{
        synchronized (this)
		{
            if (mSocksProxyServer != null)
			{
                mSocksProxyServer.stop();
                mSocksProxyServer = (ProxyServer) null;
            }
        }
  	}

    private Builder getBuilder() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean subnet = prefs.getBoolean("subnet_routing", false);
        boolean tethering = prefs.getBoolean("allow_tethering", false);
        boolean lan = prefs.getBoolean("allow_lan", false);
        boolean ip6 = prefs.getBoolean("ip6", true);
        boolean filter = prefs.getBoolean("filter_traffic", false);
        
        // Build VPN service
        Builder builder = new Builder();
        builder.setSession(getString(R.string.app_name));

        // VPN address
        String vpn4 = prefs.getString("vpn4", "10.1.10.1");
        //Log.i(TAG, "vpn4=" + vpn4);
        builder.addAddress(vpn4, 32);
        if (ip6) {
            String vpn6 = prefs.getString("vpn6", "fd00:1:fd00:1:fd00:1:fd00:1");
            //Log.i(TAG, "vpn6=" + vpn6);
            builder.addAddress(vpn6, 128);
        }

        // DNS address
        /*if (filter)
            for (InetAddress dns : getDns(this)) {
                if (ip6 || dns instanceof Inet4Address) {
                    Log.i(TAG, "dns=" + dns);
                    builder.addDnsServer(dns);
                }
            }*/

        // Subnet routing
        if (subnet) {
            // Exclude IP ranges
            List<IPUtil.CIDR> listExclude = new ArrayList<>();
            listExclude.add(new IPUtil.CIDR("127.0.0.0", 8)); // localhost

            if (tethering) {
                // USB tethering 192.168.42.x
                // Wi-Fi tethering 192.168.43.x
                listExclude.add(new IPUtil.CIDR("192.168.42.0", 23));
                // Bluetooth tethering 192.168.44.x
                listExclude.add(new IPUtil.CIDR("192.168.44.0", 24));
                // Wi-Fi direct 192.168.49.x
                listExclude.add(new IPUtil.CIDR("192.168.49.0", 24));
            }

            if (lan) {
                try {
                    Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
                    while (nis.hasMoreElements()) {
                        NetworkInterface ni = nis.nextElement();
                        if (ni != null && ni.isUp() && !ni.isLoopback() &&
							ni.getName() != null && !ni.getName().startsWith("tun"))
                            for (InterfaceAddress ia : ni.getInterfaceAddresses())
                                if (ia.getAddress() instanceof Inet4Address) {
                                    IPUtil.CIDR local = new IPUtil.CIDR(ia.getAddress(), ia.getNetworkPrefixLength());
                                    Log.i(TAG, "Excluding " + ni.getName() + " " + local);
                                    listExclude.add(local);
                                }
                    }
                } catch (SocketException ex) {
                   // Log.e(TAG, ex.toString() + "\n" + Log.getStackTraceString(ex));
                }
            }

            // https://en.wikipedia.org/wiki/Mobile_country_code
            Configuration config = getResources().getConfiguration();

            // T-Mobile Wi-Fi calling
            if (config.mcc == 310 && (config.mnc == 160 ||
				config.mnc == 200 ||
				config.mnc == 210 ||
				config.mnc == 220 ||
				config.mnc == 230 ||
				config.mnc == 240 ||
				config.mnc == 250 ||
				config.mnc == 260 ||
				config.mnc == 270 ||
				config.mnc == 310 ||
				config.mnc == 490 ||
				config.mnc == 660 ||
				config.mnc == 800)) {
                listExclude.add(new IPUtil.CIDR("66.94.2.0", 24));
                listExclude.add(new IPUtil.CIDR("66.94.6.0", 23));
                listExclude.add(new IPUtil.CIDR("66.94.8.0", 22));
                listExclude.add(new IPUtil.CIDR("208.54.0.0", 16));
            }

            // Verizon wireless calling
            if ((config.mcc == 310 &&
				(config.mnc == 4 ||
				config.mnc == 5 ||
				config.mnc == 6 ||
				config.mnc == 10 ||
				config.mnc == 12 ||
				config.mnc == 13 ||
				config.mnc == 350 ||
				config.mnc == 590 ||
				config.mnc == 820 ||
				config.mnc == 890 ||
				config.mnc == 910)) ||
				(config.mcc == 311 && (config.mnc == 12 ||
				config.mnc == 110 ||
				(config.mnc >= 270 && config.mnc <= 289) ||
				config.mnc == 390 ||
				(config.mnc >= 480 && config.mnc <= 489) ||
				config.mnc == 590)) ||
				(config.mcc == 312 && (config.mnc == 770))) {
                listExclude.add(new IPUtil.CIDR("66.174.0.0", 16)); // 66.174.0.0 - 66.174.255.255
                listExclude.add(new IPUtil.CIDR("66.82.0.0", 15)); // 69.82.0.0 - 69.83.255.255
                listExclude.add(new IPUtil.CIDR("69.96.0.0", 13)); // 69.96.0.0 - 69.103.255.255
                listExclude.add(new IPUtil.CIDR("70.192.0.0", 11)); // 70.192.0.0 - 70.223.255.255
                listExclude.add(new IPUtil.CIDR("97.128.0.0", 9)); // 97.128.0.0 - 97.255.255.255
                listExclude.add(new IPUtil.CIDR("174.192.0.0", 9)); // 174.192.0.0 - 174.255.255.255
                listExclude.add(new IPUtil.CIDR("72.96.0.0", 9)); // 72.96.0.0 - 72.127.255.255
                listExclude.add(new IPUtil.CIDR("75.192.0.0", 9)); // 75.192.0.0 - 75.255.255.255
                listExclude.add(new IPUtil.CIDR("97.0.0.0", 10)); // 97.0.0.0 - 97.63.255.255
            }

            // Broadcast
            listExclude.add(new IPUtil.CIDR("224.0.0.0", 3));

            Collections.sort(listExclude);

            try {
                InetAddress start = InetAddress.getByName("0.0.0.0");
                for (IPUtil.CIDR exclude : listExclude) {
                    Log.i(TAG, "Exclude " + exclude.getStart().getHostAddress() + "..." + exclude.getEnd().getHostAddress());
                    for (IPUtil.CIDR include : IPUtil.toCIDR(start, IPUtil.minus1(exclude.getStart())))
                        try {
                            builder.addRoute(include.address, include.prefix);
                        } catch (Throwable ex) {
                           // Log.e(TAG, ex.toString() + "\n" + Log.getStackTraceString(ex));
                        }
                    start = IPUtil.plus1(exclude.getEnd());
                }
                String end = (lan ? "255.255.255.254" : "255.255.255.255");
                for (IPUtil.CIDR include : IPUtil.toCIDR("224.0.0.0", end))
                    try {
                        builder.addRoute(include.address, include.prefix);
                    } catch (Throwable ex) {
                       // Log.e(TAG, ex.toString() + "\n" + Log.getStackTraceString(ex));
                    }
            } catch (UnknownHostException ex) {
               // Log.e(TAG, ex.toString() + "\n" + Log.getStackTraceString(ex));
            }
        } else
            builder.addRoute("0.0.0.0", 0);

       // Log.i(TAG, "IPv6=" + ip6);
        if (ip6)
            builder.addRoute("2000::", 3); // unicast

        // MTU
        int mtu = 8192;
        //Log.i(TAG, "MTU=" + mtu);
        builder.setMtu(mtu);

        // Add list of allowed applications
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                builder.addDisallowedApplication(getPackageName());
            } catch (PackageManager.NameNotFoundException ex) {
                //Log.e(TAG, ex.toString() + "\n" + Log.getStackTraceString(ex));
            }
        }

        // Build configure intent
        
        return builder;
    }

	public List<InetAddress> getDns(Context context) {
        List<InetAddress> listDns = new ArrayList<>();
        List<String> sysDns = Utils.getDefaultDNS(context);

        // Get custom DNS servers
        
		boolean ip6 = dsp.getBoolean("ip6", true);
        String vpnDns1 = dsp.getString("custom_primary_dns", null);
        String vpnDns2 = dsp.getString("custom_secondary_dns", null);
        Log.i(TAG, "DNS system=" + TextUtils.join(",", sysDns) + " VPN1=" + vpnDns1 + " VPN2=" + vpnDns2);

        if (vpnDns1 != null)
            try {
                InetAddress dns = InetAddress.getByName(vpnDns1);
                if (!(dns.isLoopbackAddress() || dns.isAnyLocalAddress()) &&
					(ip6 || dns instanceof Inet4Address))
                    listDns.add(dns);
            } catch (Throwable ignored) {
            }

        if (vpnDns2 != null)
            try {
                InetAddress dns = InetAddress.getByName(vpnDns2);
                if (!(dns.isLoopbackAddress() || dns.isAnyLocalAddress()) &&
					(ip6 || dns instanceof Inet4Address))
                    listDns.add(dns);
            } catch (Throwable ex) {
                //Log.e(TAG, ex.toString() + "\n" + Log.getStackTraceString(ex));
            }

        // Use system DNS servers only when no two custom DNS servers specified
        if (listDns.size() <= 1)
            for (String def_dns : sysDns)
                try {
                    InetAddress ddns = InetAddress.getByName(def_dns);
                    if (!listDns.contains(ddns) &&
						!(ddns.isLoopbackAddress() || ddns.isAnyLocalAddress()) &&
						(ip6 || ddns instanceof Inet4Address))
                        listDns.add(ddns);
                } catch (Throwable ex) {
                   // Log.e(TAG, ex.toString() + "\n" + Log.getStackTraceString(ex));
                }

        // Remove local DNS servers when not routing LAN
        boolean lan = dsp.getBoolean("allow_lan", false);
        boolean use_hosts = dsp.getBoolean("filter_traffic", false) && dsp.getBoolean("use_hosts", false);
        if (lan && use_hosts) {
            List<InetAddress> listLocal = new ArrayList<>();
            try {
                Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
                if (nis != null)
                    while (nis.hasMoreElements()) {
                        NetworkInterface ni = nis.nextElement();
                        if (ni != null && ni.isUp() && !ni.isLoopback()) {
                            List<InterfaceAddress> ias = ni.getInterfaceAddresses();
                            if (ias != null)
                                for (InterfaceAddress ia : ias) {
                                    InetAddress hostAddress = ia.getAddress();
                                    BigInteger host = new BigInteger(1, hostAddress.getAddress());

                                    int prefix = ia.getNetworkPrefixLength();
                                    BigInteger mask = BigInteger.valueOf(-1).shiftLeft(hostAddress.getAddress().length * 8 - prefix);

                                    for (InetAddress dns : listDns)
                                        if (hostAddress.getAddress().length == dns.getAddress().length) {
                                            BigInteger ip = new BigInteger(1, dns.getAddress());

                                            if (host.and(mask).equals(ip.and(mask))) {
                                                Log.i(TAG, "Local DNS server host=" + hostAddress + "/" + prefix + " dns=" + dns);
                                                listLocal.add(dns);
                                            }
                                        }
                                }
                        }
                    }
            } catch (Throwable ex) {
                //Log.e(TAG, ex.toString() + "\n" + Log.getStackTraceString(ex));
            }

            List<InetAddress> listDns4 = new ArrayList<>();
            List<InetAddress> listDns6 = new ArrayList<>();
            try {
                listDns4.add(InetAddress.getByName("8.8.8.8"));
                listDns4.add(InetAddress.getByName("8.8.4.4"));
                if (ip6) {
                    listDns6.add(InetAddress.getByName("2001:4860:4860::8888"));
                    listDns6.add(InetAddress.getByName("2001:4860:4860::8844"));
                }

            } catch (Throwable ex) {
               // Log.e(TAG, ex.toString() + "\n" + Log.getStackTraceString(ex));
            }

            for (InetAddress dns : listLocal) {
                listDns.remove(dns);
                if (dns instanceof Inet4Address) {
                    if (listDns4.size() > 0) {
                        listDns.add(listDns4.get(0));
                        listDns4.remove(0);
                    }
                } else {
                    if (listDns6.size() > 0) {
                        listDns.add(listDns6.get(0));
                        listDns6.remove(0);
                    }
                }
            }
        }

        return listDns;
    }
	
	private final String ab()
	{
        ArrayList arrayList = new ArrayList();
        arrayList.add("10.0.0.1");
        arrayList.add("172.16.0.1");
        arrayList.add("192.168.0.1");
        arrayList.add("169.254.1.1");
        try
		{
            for (NetworkInterface inetAddresses : Collections.list(NetworkInterface.getNetworkInterfaces()))
			{
                Iterator it = Collections.list(inetAddresses.getInetAddresses()).iterator();
                while (it.hasNext())
				{
                    InetAddress inetAddress = (InetAddress) it.next();
                    String hostAddress = inetAddress.getHostAddress();
                    if (inetAddress instanceof Inet4Address)
					{
                        if (hostAddress.startsWith("10."))
						{
                            arrayList.remove("10.0.0.1");
                        }
						else if (hostAddress.length() >= 6 && hostAddress.substring(0, 6).compareTo("172.16") >= 0 && hostAddress.substring(0, 6).compareTo("172.31") <= 0)
						{
                            arrayList.remove("172.16.0.1");
                        }
						else if (hostAddress.startsWith("192.168"))
						{
                            arrayList.remove("192.168.0.1");
                        }
                    }
                }
            }
            return arrayList.size() > 0 ? (String) arrayList.get(0) : (String) null;
        }
		catch (SocketException e)
		{
            return (String) null;
        }
    }

    private final int a(String str)
	{
        int i = str.compareTo("10.0.0.1") == 0 ? 8 : str.compareTo("172.16.0.1") == 0 ? 12 : str.compareTo("192.168.0.1") == 0 ? 16 : str.compareTo("169.254.1.1") == 0 ? 24 : 0;
        return i;
    }

    private final String b(String str)
	{
        String str3 = str.compareTo("10.0.0.1") == 0 ? "10.0.0.2" : str.compareTo("172.16.0.1") == 0 ? "172.16.0.2" : str.compareTo("192.168.0.1") == 0 ? "192.168.0.2" : str.compareTo("169.254.1.1") == 0 ? "169.254.1.2" : (String) null;
        return str3;
    }

	public static String c(String privateIpAddress)
    {
        if (0 == privateIpAddress.compareTo("10.0.0.1"))
        {
            return "10.0.0.0";
        }
        else if (0 == privateIpAddress.compareTo("172.16.0.1"))
        {
            return "172.16.0.0";
        }
        else if (0 == privateIpAddress.compareTo("192.168.0.1"))
        {
            return "192.168.0.0";
        }
        else if (0 == privateIpAddress.compareTo("169.254.1.1"))
        {
            return "169.254.1.0";
        }
        return null;
    }

	void PdnsD(boolean z)
	{
		try
		{
			if (dsp.getBoolean("dns_forwarder_key", false))
			{
				if (z)
				{
					if(dsp.getBoolean("enable_dns_key", false)){
						xBinary.ServiceGatewayDNS(this, true, dsp.getString("custom_primary_dns", "8.8.8.8"), dsp.getString("custom_secondary_dns", "8.8.4.4"));
					}else{
						xBinary.ServiceGatewayDNS(this, true, "8.8.8.8", "8.8.4.4");
					}
					//xBinary.startUDP(this, true);
					addLog("Pdnsd started.");
				}
				else
				{
					xBinary.ServiceGatewayDNS(this, false, "8.8.8.8", "8.8.4.4");
					//xBinary.startUDP(this, false);
					//addLog("Pdnsd stoped.");
				}
			}
		}
		catch (Exception e)
		{
			addLog("Something wen't wrong in pdnsd.");
		}
	}

	public boolean runCommand(String command)
	{
		java.lang.Process process = null;
		try
		{
			process = Runtime.getRuntime().exec(command);
			process.waitFor();
		}
		catch (Exception e)
		{
			addLog(e.getMessage());
			return false;
		}
		finally
		{
			try
			{
				process.destroy();
			}
			catch (Exception e)
			{
				// nothing
			}
		}
		return true;
	}

	void addLog(String str)
	{
		Log.d("", str);
	}
}
