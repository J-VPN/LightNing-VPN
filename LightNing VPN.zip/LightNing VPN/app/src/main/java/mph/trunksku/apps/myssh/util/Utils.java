package mph.trunksku.apps.myssh.util;
import android.content.*;
import android.content.pm.*;
import java.io.*;
import android.net.*;
import java.lang.reflect.*;
import android.os.*;
import java.util.*;
import java.net.*;
import mph.trunksku.apps.myssh.logger.*;
import android.annotation.*;
import org.xbill.DNS.*;
import android.text.*;

public class Utils
{

	private static Context mContext;
	public Utils(Context c)
	{
		mContext = c;
	}
	public static String vb()
	{
        try
		{
            PackageInfo packageInfo = mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 128);
            return packageInfo.versionName + " Build " + packageInfo.versionCode;
        }
		catch (Exception e)
		{
            return "-";
        }
    }
	
	
	public static List<String> getDefaultDNS(Context context) {
        String dns1 = null;
        String dns2 = null;
        if (Build.VERSION.SDK_INT >= 26) {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network an = cm.getActiveNetwork();
            if (an != null) {
                LinkProperties lp = cm.getLinkProperties(an);
                if (lp != null) {
                    List<InetAddress> dns = lp.getDnsServers();
                    if (dns != null) {
                        if (dns.size() > 0)
                            dns1 = dns.get(0).getHostAddress();
                        if (dns.size() > 1)
                            dns2 = dns.get(1).getHostAddress();
                        /*for (InetAddress d : dns)
                            Log.i(TAG, "DNS from LP: " + d.getHostAddress());*/
                    }
                }
            }
        } else {
            dns1 = jni_getprop("net.dns1");
            dns2 = jni_getprop("net.dns2");
        }

        if (!TextUtils.isEmpty(dns1))
            dns1 = dns1.split("%")[0];
        if (!TextUtils.isEmpty(dns2))
            dns2 = dns2.split("%")[0];

        List<String> listDns = new ArrayList<>();
        listDns.add(TextUtils.isEmpty(dns1) ? "8.8.8.8" : dns1);
        listDns.add(TextUtils.isEmpty(dns2) ? "8.8.4.4" : dns2);
        return listDns;
    }

	private static String jni_getprop(String p0)
	{
		// TODO: Implement this method
		return null;
	}
	
	
	@TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static Collection<InetAddress> getActiveNetworkDnsResolvers(Context context)
    {
        ArrayList<InetAddress> dnsAddresses = new ArrayList<InetAddress>();

        try
        {
            /*

			 Hidden API
			 - only available in Android 4.0+
			 - no guarantee will be available beyond 4.2, or on all vendor devices 

			 core/java/android/net/ConnectivityManager.java:

			 /** {@hide} * /
			 public LinkProperties getActiveLinkProperties() {
			 try {
			 return mService.getActiveLinkProperties();
			 } catch (RemoteException e) {
			 return null;
			 }
			 }

			 services/java/com/android/server/ConnectivityService.java:

			 /*
			 * Return LinkProperties for the active (i.e., connected) default
			 * network interface.  It is assumed that at most one default network
			 * is active at a time. If more than one is active, it is indeterminate
			 * which will be returned.
			 * @return the ip properties for the active network, or {@code null} if
			 * none is active
			 * /
			 @Override
			 public LinkProperties getActiveLinkProperties() {
			 return getLinkProperties(mActiveDefaultNetwork);
			 }

			 @Override
			 public LinkProperties getLinkProperties(int networkType) {
			 enforceAccessPermission();
			 if (isNetworkTypeValid(networkType)) {
			 final NetworkStateTracker tracker = mNetTrackers[networkType];
			 if (tracker != null) {
			 return tracker.getLinkProperties();
			 }
			 }
			 return null;
			 }

			 core/java/android/net/LinkProperties.java:

			 public Collection<InetAddress> getDnses() {
			 return Collections.unmodifiableCollection(mDnses);
			 }

			 */

            ConnectivityManager connectivityManager =
				(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);

            Class<?> LinkPropertiesClass = Class.forName("android.net.LinkProperties");

            Method getActiveLinkPropertiesMethod = ConnectivityManager.class.getMethod("getActiveLinkProperties", new Class []{});

            Object linkProperties = getActiveLinkPropertiesMethod.invoke(connectivityManager);

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP)
            {
                Method getDnsesMethod = LinkPropertiesClass.getMethod("getDnses", new Class []{});

                Collection<?> dnses = (Collection<?>)getDnsesMethod.invoke(linkProperties);

                for (Object dns : dnses)
                {
                    dnsAddresses.add((InetAddress)dns);
                }
            }
            else
            {
                // LinkProperties is now available in API 21 (and the DNS function signature has changed)
                for (InetAddress dns : ((LinkProperties)linkProperties).getDnsServers())
                {
                    dnsAddresses.add(dns);
                }
            }
        }
        catch (Exception e)
        {
            Log.d("", e.getMessage());
        }
     
        return dnsAddresses;
    }

    public static void updateDnsResolvers(Context context)
    {
        // Custom DNS resolver only used in VpnService mode. Also, note
        // that getActiveNetworkDnsResolvers uses hidden APIs available
        // only in Android 4.0+.

        if (!Utils.hasVpnService())
        {
            return;
        }

        // Update DNS resolver settings. These settings are used outside the tunnel
        // but while the VpnService tun device is still up. We try to use the correct
        // resolver for the active underlying network.            

        String dnsResolver;
        ArrayList<String> dnsResolvers = new ArrayList<String>();
        for (InetAddress activeNetworkResolver : Utils.getActiveNetworkDnsResolvers(context))
        {
            dnsResolver = activeNetworkResolver.getHostAddress();
            dnsResolvers.add(dnsResolver);
            // Disabled for now -- too noisy (not changing to Log.g since it's SENSITIVE)
            //MyLog.v(R.string.dns_resolver, MyLog.Sensitivity.SENSITIVE_LOG, dnsResolver);
        }
        dnsResolver = "8.8.4.4";
        dnsResolvers.add(dnsResolver);
        // Disabled for now -- too noisy (not changing to Log.g since it's SENSITIVE)
        //MyLog.v(R.string.dns_resolver, MyLog.Sensitivity.SENSITIVE_LOG, dnsResolver);
        ResolverConfig.refresh(dnsResolvers);        
    }
	
	public static boolean hasVpnService()
    {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH;
    }
	
	public static String f() {
		String str = null;
        try {
            InputStream openFileInput = mContext.openFileInput("config.mz");
            if (openFileInput != null) {
                Reader reader = new InputStreamReader(openFileInput);
                BufferedReader bufferedReader = new BufferedReader(reader);
                String str2 = "";
                StringBuilder stringBuilder = new StringBuilder();
                while (true) {
                    String readLine = bufferedReader.readLine();
                    str2 = readLine;
                    if (readLine == null) {
                        break;
                    }
                    stringBuilder.append(str2);
                }
                openFileInput.close();
                str = stringBuilder.toString();
            }
        } catch (FileNotFoundException e) {

        } catch (IOException e3) {

		}
	 return XxTea.decryptBase64StringToString(str, "123456");
    }
	
	public static void v(String data) {
		try {
            FileOutputStream openFileOutput = mContext.openFileOutput("config.mz", 0);
            openFileOutput.write(data.getBytes());
            openFileOutput.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
}
