package mph.trunksku.apps.myssh.core;

import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;
import javax.net.ssl.*;
import mph.trunksku.apps.myssh.*;
import mph.trunksku.apps.myssh.fragment.*;
import org.apache.http.protocol.*;
import mph.trunksku.apps.myssh.model.*;
import java.nio.channels.*;
import android.annotation.*;

public class SSLSupport
{

	private Socket input;

	private Config http;

	private HttpsURLConnection u;

	public SSLSocket b;

	public Socket socket;
	
	public SSLSupport(Socket in){
		input = in;
		http = ApplicationBase.getUtils();
		
	}

	public Socket socket() {
        try {
            String readRequestHeader = readRequestHeader();
            if (readRequestHeader == null || !readRequestHeader.contains(":")) {
                addLog(new StringBuffer().append("Invalid request: ").append(readRequestHeader).toString());
                return (Socket) null;
            }
            String host = readRequestHeader.split(":")[0];
            int port = Integer.parseInt(readRequestHeader.split(":")[1]);
            sendForwardSuccess(input);
            socket = SocketChannel.open().socket();
			socket.connect(new InetSocketAddress(host, port));
			
            //doVpnProtect(socket);
            //socket = doSSLHandshake(socket, utils.getPayload(), 443);
		    if(socket.isConnected()){
				//socket = newSocket(http.getPayload(), http.getSSHHost(), Integer.parseInt(http.getSSHPort()));
				socket = doSSLHandshake(http.getSSHHost(), http.getPayload(), Integer.parseInt(http.getSSHPort()));
				//socket = doTLSHandshake(socket, http.getPayload(), http.getSSHHost(), Integer.valueOf(http.getSSHPort()));
			}
			return socket;
        } catch (Exception e) {
            //addLog(new StringBuffer().append("Exception in proxy thread: ").append(e.getMessage()).toString());
       		return null;
		}
    }
	
	public Socket newSocket(String sni, String host, int port) {
		try {
            TLSSocketFactory d2 = new TLSSocketFactory();
			if (sni.isEmpty()) {
				((SSLSocket)d2.createSocket(host, port)).startHandshake();
			} else {
				URL uRL = new URL("https://" + sni);
				String string4 = uRL.getHost();
				if (uRL.getPort() > 0) {
					string4 = string4 + ":" + uRL.getPort();
				}
				if (!uRL.getPath().equals((Object)"/")) {
					string4 = string4 + uRL.getPath();
				}
				/*if (kpn.soft.dev.kpnrevolution.c.h.M() || kpn.soft.dev.kpnrevolution.c.h.L()) {
					string4 = j.a(string4);
				}*/
				u = /*true ? (HttpsURLConnection)uRL.openConnection(new Proxy(Proxy.Type.HTTP, this.v.a())) :*/ (HttpsURLConnection)uRL.openConnection();
				this.u.setHostnameVerifier(new HostnameVerifier(){
						@SuppressLint(value={"BadHostnameVerifier"})
						public boolean verify(String string, SSLSession sSLSession) {
							return true;
						}
					});
				this.u.setSSLSocketFactory((SSLSocketFactory)d2);
				this.u.connect();
			}
			return b;
        } catch (Exception e) {
            //addLog(new StringBuffer().append("Exception in proxy thread: ").append(e.getMessage()).toString());
       		return null;
		}
	}
	
	public Socket startSocket() {
		try{
			Socket socket = SocketChannel.open().socket();
			socket.connect(new InetSocketAddress(http.getSSHHost(), Integer.valueOf(http.getSSHPort())), 10000);
			if(socket.isConnected()){
				socket = doTLSHandshake(socket, http.getPayload(), http.getSSHHost(), Integer.valueOf(http.getSSHPort()));
			}
			return socket;
		}catch(Exception e){
			return null;
		}
	}
	
	private Socket doTLSHandshake(Socket socket, String sni, String host, int port) {
		SSLSocket sslSocket;
		try{
			TLSSocketFactory factory = new TLSSocketFactory();
			sslSocket = (SSLSocket) factory.createSocket(socket, sni, port, true);
			sslSocket.getClass().getMethod("setHostname", new Class[]{String.class}).invoke(sslSocket, new Object[]{sni});
			sslSocket.startHandshake();
			sslSocket.getOutputStream().write(String.format("CONNECT %s:%s HTTP/1.1\r\nHost: %s\r\n\r\n", new Object[]{host, port, sni}).getBytes());
			InputStream inStream = sslSocket.getInputStream();
			ResponseHeader resHeader = new HTTPHeaderReader(inStream).read();
			if (resHeader.getBodyLength() <= 0 || inStream.read(new byte[resHeader.getBodyLength()]) != -1) {
				if (resHeader.getStatusText().toLowerCase().equals("connection established")) {
					//this.listener.onConnectionCompleted();
				}
				return sslSocket;
			}
		}catch(Exception e){
			//addLog(e.getMessage());
			return null;
		}
		return null;
	}

    /*private String readRequestHeader() throws IOException {
        Reader reader = new InputStreamReader(input.getInputStream());
		BufferedReader lineReader = new BufferedReader(reader);

	    String str = null;
		String readLine;
        do {
            readLine = lineReader.readLine();
            if (readLine == null) {
				str = null;
            }
            if (readLine.startsWith("CONNECT")) {
                str = readLine.split(" ")[1];
            }
        } while (readLine.length() != 0);
        return str;
    }*/

    private String readRequestHeader() throws IOException {
        Reader reader = new InputStreamReader(input.getInputStream());
		BufferedReader lineReader = new BufferedReader(reader);
        String request = null;
        String line;
        while ((line = lineReader.readLine()) != null) {
            if (line.startsWith("CONNECT") && request == null) {
                request = line.split(" ")[1];
            }
            if (line.length() == 0) {
                return request;
            }
        }
        return null;
    }

    private void sendForwardSuccess(Socket socket) throws IOException {
        String respond = "HTTP/1.1 200 OK\r\n\r\n";
        socket.getOutputStream().write(respond.getBytes());
        socket.getOutputStream().flush();
    }

	private Socket doSSLHandshake(Socket socket, String host, String sni, int port) throws IOException {
        TrustManager[] trustAllCerts = new TrustManager[] {
			new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}
				public void checkClientTrusted(
					java.security.cert.X509Certificate[] certs, String authType) {
				}
				public void checkServerTrusted(
					java.security.cert.X509Certificate[] certs, String authType) {
				}
			}
		};
        try {
            SSLContext sSLContext = SSLContext.getInstance("SSL");
            KeyManager[] keyManagerArr = (KeyManager[]) null;
            sSLContext.init(keyManagerArr, trustAllCerts, new SecureRandom());
            SSLSocket socket3 = (SSLSocket) sSLContext.getSocketFactory().createSocket(socket, host, port, true);
            if (sSLContext.getSocketFactory() instanceof android.net.SSLCertificateSocketFactory && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
				((android.net.SSLCertificateSocketFactory)sSLContext.getSocketFactory()).setHostname(socket, sni);
			} else {
				try {
					socket.getClass().getMethod("setHostname", String.class).invoke(socket, sni);
					//addLog("Setting up SNI: "+sni);
				} catch (Throwable e) {
					// ignore any error, we just can't set the hostname...
				}
			}
			socket3.setEnabledProtocols(socket3.getSupportedProtocols());
            socket3.addHandshakeCompletedListener(new mHandshakeCompletedListener(host, port, socket3));
            socket3.startHandshake();
            return socket3;
        } catch (Exception e) {
            IOException iOException = new IOException(new StringBuffer().append("Could not do SSL handshake: ").append(e).toString());
            throw iOException;
        }
    }
	
	private SSLSocket doSSLHandshake(String host, String sni, int port) throws IOException {
        try {
			TLSSocketFactory tsf = new TLSSocketFactory();
            SSLSocket socket = (SSLSocket) tsf.createSocket(host, port);
				try {
					socket.getClass().getMethod("setHostname", String.class).invoke(socket, sni);
					//addLog("Setting up SNI: "+sni);
				} catch (Throwable e) {
					// ignore any error, we just can't set the hostname...
				}
			
			//socket.setEnabledProtocols(socket.getSupportedProtocols());
            socket.addHandshakeCompletedListener(new mHandshakeCompletedListener(host, port, socket));
            addLog("Starting SSL Handshake...");
			socket.startHandshake();
			return socket;
        } catch (Exception e) {
            IOException iOException = new IOException(new StringBuffer().append("Could not do SSL handshake: ").append(e).toString());
            throw iOException;
        }
    }

	/*private SSLSocket doSSLHandshake(String host, String sni, int port) throws IOException {
        TrustManager[] trustAllCerts = new TrustManager[] {
			new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}
				public void checkClientTrusted(
					java.security.cert.X509Certificate[] certs, String authType) {
				}
				public void checkServerTrusted(
					java.security.cert.X509Certificate[] certs, String authType) {
				}
			}
		};
        try {
            SSLContext sSLContext = SSLContext.getInstance("TLS");
            KeyManager[] keyManagerArr = (KeyManager[]) null;
            sSLContext.init(keyManagerArr, trustAllCerts, new SecureRandom());
            SSLSocket socket = (SSLSocket) sSLContext.getSocketFactory().createSocket(host, port);
            if (sSLContext.getSocketFactory() instanceof android.net.SSLCertificateSocketFactory && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
				((android.net.SSLCertificateSocketFactory)sSLContext.getSocketFactory()).setHostname(socket, sni);
			} else {
				try {
					socket.getClass().getMethod("setHostname", String.class).invoke(socket, sni);
					//addLog("Setting up SNI: "+sni);
				} catch (Throwable e) {
					// ignore any error, we just can't set the hostname...
				}
			}
			//socket.setEnabledProtocols(socket.getSupportedProtocols());
            socket.addHandshakeCompletedListener(new mHandshakeCompletedListener(host, port, socket));
            addLog("Starting SSL Handshake...");
			socket.startHandshake();
			return socket;
        } catch (Exception e) {
            IOException iOException = new IOException(new StringBuffer().append("Could not do SSL handshake: ").append(e).toString());
            throw iOException;
        }
    }*/

	class mHandshakeCompletedListener implements HandshakeCompletedListener {
        private final String val$host;
        private final int val$port;
        private final SSLSocket val$sslSocket;

        mHandshakeCompletedListener( String str, int i, SSLSocket sSLSocket) {
            this.val$host = str;
            this.val$port = i;
            this.val$sslSocket = sSLSocket;
        }

        public void handshakeCompleted(HandshakeCompletedEvent handshakeCompletedEvent) {
           // addLog(new StringBuffer().append("<b>Established ").append(handshakeCompletedEvent.getSession().getProtocol()).append(" connection with ").append(val$host).append(":").append(this.val$port).append(" using ").append(handshakeCompletedEvent.getCipherSuite()).append("</b>").toString());
			//addLog(new StringBuffer().append("<b>Established ").append(handshakeCompletedEvent.getSession().getProtocol()).append(" connection ").append("using ").append(handshakeCompletedEvent.getCipherSuite()).append("</b>").toString());
		    //addLog(new StringBuffer().append("Supported cipher suites: ").append(Arrays.toString(this.val$sslSocket.getSupportedCipherSuites())).toString());
            //addLog(new StringBuffer().append("Enabled cipher suites: ").append(Arrays.toString(this.val$sslSocket.getEnabledCipherSuites())).toString());
            addLog(new StringBuffer().append("SSL: Supported protocols: <br>").append(Arrays.toString(val$sslSocket.getSupportedProtocols())).toString().replace("[", "").replace("]", "").replace(",", "<br>"));
			addLog(new StringBuffer().append("SSL: Enabled protocols: <br>").append(Arrays.toString(val$sslSocket.getEnabledProtocols())).toString().replace("[", "").replace("]", "").replace(",", "<br>"));
			addLog("SSL: Using cipher " + handshakeCompletedEvent.getSession().getCipherSuite());
			addLog("SSL: Using protocol " + handshakeCompletedEvent.getSession().getProtocol());
			addLog("SSL: Handshake finished");
        }
    }

	void addLog(String str){
		LogFragment.addLog(str);
	}

}

