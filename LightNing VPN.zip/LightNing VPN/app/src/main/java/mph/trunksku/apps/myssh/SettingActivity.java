package mph.trunksku.apps.myssh;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.preference.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;
import android.widget.LinearLayout.*;
import mph.trunksku.apps.myssh.util.*;
import net.finalfixvpn.ml2.*;
import android.support.v7.widget.Toolbar;

public class SettingActivity extends AppCompatActivity {

	public static class SettingFragment extends PreferenceFragment implements SecurePreferences.OnSharedPreferenceChangeListener {
		public static final String KEY_PREF_LANGUAGE = "pref_key_language";

		private Preference button;

		private SharedPreferences mSecurePrefs;

		private CheckBoxPreference mCustomPayloadPref;

		private EditTextPreference mPayloadPref;

		private EditTextPreference mSNIPref;

		private CheckBoxPreference mCustomRemotePref;

		private EditTextPreference mRemotePref;

		private EditTextPreference mRepoPref;

		private PreferenceCategory advanceCat;

		private PreferenceCategory systemCat;

		private SwitchPreference mShowNotif;

		private SwitchPreference mSoundNotif;

		private SwitchPreference mVibrateNotif;

		private CheckBoxPreference mDnsForwardPref;

		private CheckBoxPreference mEnableDnsPref;

		private EditTextPreference mPrimaryDnsPref;

		private EditTextPreference mSecondaryDnsPref;

		private SwitchPreference mSubnet;

		private SwitchPreference mTether;

		private SwitchPreference mLan;

		@Override
		public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			addPreferencesFromResource(R.xml.preferences);
			Constraints ct = new Constraints();
			mSecurePrefs = ApplicationBase.getSharedPreferences();
		    advanceCat = (PreferenceCategory) findPreference("advance_setting");
			systemCat = (PreferenceCategory) findPreference("system_setting");

			mCustomPayloadPref = (CheckBoxPreference) findPreference("custom_payload_key");
			mCustomPayloadPref.setDefaultValue(mSecurePrefs.getBoolean("custom_payload_key", false));

			mCustomRemotePref = (CheckBoxPreference) findPreference("custom_remote_key");
			mCustomRemotePref.setDefaultValue(mSecurePrefs.getBoolean("custom_remote_key", false));

			mDnsForwardPref = (CheckBoxPreference) findPreference("dns_forwarder_key");
			//mDnsForwardPref.setDefaultValue(mSecurePrefs.getBoolean("dns_forwarder_key", false));

			mEnableDnsPref = (CheckBoxPreference) findPreference("enable_dns_key");
			//mEnableDnsPref.setDefaultValue(mSecurePrefs.getBoolean("enable_dns_key", false));

			mPrimaryDnsPref = (EditTextPreference) findPreference("custom_primary_dns");
			mPrimaryDnsPref.setDependency("enable_dns_key");
			mPrimaryDnsPref.setDefaultValue("8.8.8.8");

			mSecondaryDnsPref = (EditTextPreference) findPreference("custom_secondary_dns");
			mSecondaryDnsPref.setDependency("enable_dns_key");
			mSecondaryDnsPref.setDefaultValue("8.8.4.4");

			if(mDnsForwardPref.isChecked()){
				advanceCat.addPreference(mEnableDnsPref);
				if(mEnableDnsPref.isChecked()){
					advanceCat.addPreference(mPrimaryDnsPref);
					advanceCat.addPreference(mSecondaryDnsPref);
				}else{
					advanceCat.removePreference(mPrimaryDnsPref);
					advanceCat.removePreference(mSecondaryDnsPref);
				}
			}else{
				advanceCat.removePreference(mEnableDnsPref);
				advanceCat.removePreference(mPrimaryDnsPref);
				advanceCat.removePreference(mSecondaryDnsPref);
			}

			mSubnet = (SwitchPreference) findPreference("subnet_routing");
			mTether = (SwitchPreference) findPreference("allow_tethering");
			mLan = (SwitchPreference) findPreference("allow_lan");

			if(mSubnet.isChecked()){
				advanceCat.addPreference(mTether);
				advanceCat.addPreference(mLan);
			}else{
				advanceCat.removePreference(mTether);
				advanceCat.removePreference(mLan);
			}

			mShowNotif = (SwitchPreference) findPreference("show_notification");
			mSoundNotif = (SwitchPreference) findPreference("sound_notification");
			mVibrateNotif = (SwitchPreference) findPreference("vibrate_notification");

			mPayloadPref = (EditTextPreference) findPreference("custom_payload");
			mPayloadPref.setDependency("custom_payload_key");
			mPayloadPref.setDefaultValue("CONNECT [host_port] [protocol][crlf]Host: m.google.com[crlf]X-Online-Host: m.google.com[crlf]Connection: Keep-Alive[crlf][crlf]");
			mSNIPref = (EditTextPreference) findPreference("custom_sni");
			mSNIPref.setDependency("custom_payload_key");
			mSNIPref.setDefaultValue("www.google.com");
			mRemotePref = (EditTextPreference) findPreference("custom_remote");
			mRemotePref.setDependency("custom_remote_key");
			mRemotePref.setDefaultValue("proxy:port");
			mRepoPref = (EditTextPreference) findPreference("custom_update_url");
			SwitchPreference darkTheme = (SwitchPreference) findPreference("use_dark_theme");

			if(mCustomPayloadPref.isChecked()){
				advanceCat.addPreference(mPayloadPref);
				advanceCat.addPreference(mSNIPref);
			}else{
				advanceCat.removePreference(mPayloadPref);
				advanceCat.removePreference(mSNIPref);
			}
			if(mCustomRemotePref.isChecked()){
				advanceCat.addPreference(mRemotePref);
			}else{
				advanceCat.removePreference(mRemotePref);
			}
			if(mShowNotif.isChecked()){
				systemCat.addPreference(mSoundNotif);
				systemCat.addPreference(mVibrateNotif);
			}else{
				systemCat.removePreference(mSoundNotif);
				systemCat.removePreference(mVibrateNotif);
			}
			/*button = findPreference("bufferSize");
			 button.setSummary(new StringBuffer().append(mSecurePrefs.getString("sndBuf", "0")).append(" | ").append(mSecurePrefs.getString("rcvBuf", "0")));

			 button.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
			 @Override
			 public boolean onPreferenceClick(Preference preference) {
			 new BufferSizeDialog(getActivity()).show();
			 return true;
			 }
			 });*/
		}

		@Override
		public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
			switch (key) {
		//		case "update_app":
		//	AppUpdater appUpdater = new AppUpdater(getActivity());
		//	appUpdater.setUpdateFrom(UpdateFrom.JSON);
		//    appUpdater.setUpdateJSON("https://pastebin.com/raw/7YNCP7zn");
		//	appUpdater.setDisplay(Display.SNACKBAR);
		//	appUpdater.showAppUpdated(true);
		//	appUpdater.start();
			//		break;
				case "custom_payload_key":
					mSecurePrefs.edit().putBoolean(key, mCustomPayloadPref.isChecked()).commit();
					if(mCustomPayloadPref.isChecked()){
						advanceCat.addPreference(mPayloadPref);
						advanceCat.addPreference(mSNIPref);
					}else{
						advanceCat.removePreference(mPayloadPref);
						advanceCat.removePreference(mSNIPref);
					}
					break;
				case "custom_payload":
					mSecurePrefs.edit().putString(key, sharedPreferences.getString("custom_payload", "")).commit();
					break;
				case "custom_sni":
					mSecurePrefs.edit().putString(key, sharedPreferences.getString("custom_sni", "")).commit();
					break;
				case "custom_remote_key":
					mSecurePrefs.edit().putBoolean(key, mCustomRemotePref.isChecked()).commit();
					if(mCustomRemotePref.isChecked()){
						advanceCat.addPreference(mRemotePref);
					}else{
						advanceCat.removePreference(mRemotePref);
					}
					break;
				case "subnet_routing":
					if(mSubnet.isChecked()){
						advanceCat.addPreference(mTether);
						advanceCat.addPreference(mLan);
					}else{
						advanceCat.removePreference(mTether);
						advanceCat.removePreference(mLan);
					}
					break;
				case "custom_remote":
					mSecurePrefs.edit().putString(key, sharedPreferences.getString("custom_remote", "")).commit();
					break;
				case "dns_forwarder_key":
					if(mDnsForwardPref.isChecked()){
						advanceCat.addPreference(mEnableDnsPref);
						if(mEnableDnsPref.isChecked()){
							advanceCat.addPreference(mPrimaryDnsPref);
							advanceCat.addPreference(mSecondaryDnsPref);
						}else{
							advanceCat.removePreference(mPrimaryDnsPref);
							advanceCat.removePreference(mSecondaryDnsPref);
						}
					}else{
						advanceCat.removePreference(mEnableDnsPref);
						advanceCat.removePreference(mPrimaryDnsPref);
						advanceCat.removePreference(mSecondaryDnsPref);
					}
					break;
				case "enable_dns_key":
					if(mEnableDnsPref.isChecked()){
						advanceCat.addPreference(mPrimaryDnsPref);
						advanceCat.addPreference(mSecondaryDnsPref);
					}else{
						advanceCat.removePreference(mPrimaryDnsPref);
						advanceCat.removePreference(mSecondaryDnsPref);
					}
					break;
				case "show_notification":
					if(mShowNotif.isChecked()){
						systemCat.addPreference(mSoundNotif);
						systemCat.addPreference(mVibrateNotif);
					}else{
						systemCat.removePreference(mSoundNotif);
						systemCat.removePreference(mVibrateNotif);
					}
					break;
				case "vibrate_notification":
						
						break;
				case "use_dark_theme":
					getActivity().startActivity(new Intent(getActivity(), MainActivity.class))/*.putExtra(MainActivity.LAUNCH_FRAGMENT, MainActivity.FRAGMENT_SETTINGS).putExtra(MainActivity.LAUNCH_NEED_RECREATE, true))*/;
					break;
			}
			//getActivity().recreate(); // necessary here because this Activity is currently running and thus a recreate() in onResume() would be too late
		}

		@Override
		public void onResume() {
			super.onResume();
			// documentation requires that a reference to the listener is kept as long as it may be called, which is the case as it can only be called from this Fragment
			//getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
			mSecurePrefs.registerOnSharedPreferenceChangeListener(this);
		}

		@Override
		public void onPause() {
			super.onPause();
			//getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
			mSecurePrefs.unregisterOnSharedPreferenceChangeListener(this);
		}
	}

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
		LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(1);
		ll.setId(1);
		//ll.setPadding(40,0,40,0);
        ll.setLayoutParams(layoutParams);
		Toolbar tb = new Toolbar(this);
		tb.setTitleTextColor(Color.BLACK);
		tb.setBackgroundColor(Color.parseColor(getString(R.color.colorPrimary)));
		tb.setPopupTheme(R.style.ThemeOverlay_AppCompat_Light);
		ll.addView(tb);
		FrameLayout fl = new FrameLayout(this);
		ll.addView(fl);
	    setContentView(ll);
        setSupportActionBar(tb);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        FragmentTransaction beginTransaction = getFragmentManager().beginTransaction();
        beginTransaction.replace(ll.getId(), new SettingFragment());
        beginTransaction.commit();
    }

	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		super.onBackPressed();
	}


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }
}


