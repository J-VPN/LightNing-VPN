package mph.trunksku.apps.myssh.fragment;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.ViewGroup.*;
import android.widget.*;
import net.finalfixvpn.ml2.*;
import mph.trunksku.apps.myssh.logger.*;
import mph.trunksku.apps.myssh.util.*;

public class LogFragment extends Fragment
{
    private static LogView mLogView;
    private LinearLayout mScrollView;

	@Override
    public void onCreate(Bundle bundle)
	{
        super.onCreate(bundle);
        setHasOptionsMenu(true);
	}

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		this.mScrollView = new LinearLayout(getActivity());
        LayoutParams scrollParams = new LayoutParams(-1, -1);
        this.mScrollView.setLayoutParams(scrollParams);
        this.mLogView = new LogView(getActivity());
        LayoutParams logParams = new LayoutParams(scrollParams);
        logParams.height = logParams.WRAP_CONTENT;
        this.mLogView.setLayoutParams(logParams);
        this.mLogView.setClickable(true);
        this.mLogView.setFocusable(true);

        this.mScrollView.addView(this.mLogView);
        return this.mScrollView;
    }
    public static LogView getLogView()
	{
        return mLogView;
    }

	@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater)
	{
		menuInflater.inflate(R.menu.menu_log, menu);
        super.onCreateOptionsMenu(menu, menuInflater);
    }

	@Override
    public boolean onOptionsItemSelected(MenuItem menuItem)
	{
		String data = LogView.arrayList.toString().replace(", ", "\n");
		switch (menuItem.getItemId())
		{
			case R.id.xCopy:
				copyToClipboard(getActivity(), data);
				return true;
			case R.id.xClear:
				LogView.arrayList.clear();
				addLog(new StringBuffer().append("Running on ").append(Build.BRAND).append(" ").append(Build.MODEL).append(" (").append(Build.PRODUCT).append(") ").append(Build.MANUFACTURER).append(", Android API ").append(Build.VERSION.SDK).toString());
				addLog("Application version: " + Utils.vb());
				addLog("Log Cleared");
				return true;
			case R.id.xShare:
				Intent shareIntent = new Intent(Intent.ACTION_SEND);
				shareIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				shareIntent.setType("text/plain");
				shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, data);
				startActivity(shareIntent); 
				return true;
			default:
				return super.onOptionsItemSelected(menuItem);
        }
    }

	public static void copyToClipboard(Context context, String str)
	{
        if (android.os.Build.VERSION.SDK_INT >= 11)
		{
            ((android.content.ClipboardManager) context.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("CDCEVPN-log", str));
        }
		else
		{
            ((android.text.ClipboardManager) context.getSystemService("clipboard")).setText(str);
        }
        Toast.makeText(context, "Copy to Clipboard", 0).show();
    }

	public static void clear()
	{
		LogView.arrayList.clear();
		addLog(new StringBuffer().append("Running on ").append(Build.BRAND).append(" ").append(Build.MODEL).append(" (").append(Build.PRODUCT).append(") ").append(Build.MANUFACTURER).append(", Android API ").append(Build.VERSION.SDK).toString());
		addLog("Application version: " + Utils.vb());
	}

	public static void addLog(String str)
	{
		Log.i("EasySSH", str);
	}

	public static void addLog(String tag, String str)
	{
		Log.i(tag, str);
	}

	public void onStart()
	{
        super.onStart();
        LogWrapper logWrapper = new LogWrapper();
		Log.setLogNode(logWrapper);
		MessageOnlyLogFilter msgFilter = new MessageOnlyLogFilter();
		logWrapper.setNext(msgFilter);
		// this.logFragment = (LogFragment) getSupportFragmentManager().findFragmentById(R.id.log_window);
		msgFilter.setNext(getLogView());
	}
}

