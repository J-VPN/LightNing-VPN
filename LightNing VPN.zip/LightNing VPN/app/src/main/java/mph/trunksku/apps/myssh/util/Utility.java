package mph.trunksku.apps.myssh.util;

import android.content.Context;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.*;

public class Utility {
    private static final String TAG = "Ssl";

	private static Context context;

    public Utility(Context c){
		context = c;
	}

    public static void checkAndExtract() {
        File file = new File(new StringBuffer().append(context.getFilesDir().getPath()).append("/ssl").toString());
        if (!file.exists()) {
            try {
                InputStream open = context.getAssets().open("ssl");

                OutputStream outputStream = new FileOutputStream(new StringBuffer().append(context.getFilesDir().getPath()).append("/ssl").toString());
                byte[] bArr = new byte[512];
                while (true) {
                    int read = open.read(bArr);
                    int i = read;
                    if (read <= -1) {
                        break;
                    }
                    outputStream.write(bArr, 0, i);
                }
                open.close();
                outputStream.flush();
                outputStream.close();
                Runtime runtime = Runtime.getRuntime();
                runtime.exec(new StringBuffer().append("chmod 777 ").append(context.getFilesDir().getPath()).append("/ssl").toString());
            } catch (Exception e) {

            }
        }
    }

    public boolean isRunning() {
        File file = new File(new StringBuffer().append(context.getFilesDir().getPath()).append("/pid").toString());
        return file.exists();
    }

    public void start() {
        if (!isRunning()) {
            try {
                Runtime runtime = Runtime.getRuntime();
                runtime.exec(new StringBuffer().append(context.getFilesDir().getPath()).append("/ssl").append(" ").append(context.getFilesDir().getPath()).append("/ssl.conf").toString()).waitFor();
            } catch (Exception e) {

            }
        }
    }

	public void stop() {
		if (isRunning()) { // still alive!
			String pid = "";

			try {
				BufferedReader br = new BufferedReader(new FileReader(context.getFilesDir().getPath() + "/pid"));
				pid = br.readLine();
			} catch (IOException e) {
				Log.e(TAG, "Failed to read PID file", e);
			}

			Log.d(TAG, "pid = " + pid);

			if (!pid.trim().equals("")) {
				try {
					Runtime.getRuntime().exec("kill " + pid).waitFor();
				} catch (Exception e) {
					Log.e(TAG, "Failed to kill stunnel", e);
				}

				if (isRunning()) {
					// presumed dead, remove pid
					//noinspection ResultOfMethodCallIgnored
					new File(context.getFilesDir().getPath() + "/pid").delete();
				}
			}
		}
	}

    public String readConfig() {
        File file = new File(new StringBuilder().append(context.getFilesDir().getPath()).append("config").toString());
        if (!file.exists()) {
            return "client = yes\nlog = overwrite\noutput = " +context.getFilesDir().getPath()+ "/log\npid = "+context.getFilesDir().getPath()+"/pid\n[openvpn]\naccept = 127.0.0.1:1998\nconnect = smart.vibalgroup.com.routeme.ga:443\nsni = m.viber.com:443\n";
        }
        try {
            InputStream inputStream = new FileInputStream(file);
            byte[] readInputStream = readInputStream(inputStream);
            if (readInputStream == null) {
                return (String) null;
            }
			String str = new String(readInputStream, "UTF-8");
            return str;
        } catch (Exception e) {
            Exception exception = e;
            return (String) null;
        }
    }

	public void setupConfig(String host, String port, String sni) {
		//noinspection ResultOfMethodCallIgnored
		File file = new File(context.getFilesDir().getPath() + "/ssl.conf");
		if (file.exists()) {
			file.delete();
		}
		try {
			FileOutputStream fileOutputStream = new FileOutputStream(context.getFilesDir().getPath() + "/ssl.conf");
			try {
				String conf = "client = yes\nlog = overwrite\noutput = " +context.getFilesDir().getPath()+ "/log\npid = "+context.getFilesDir().getPath()+"/pid\n[ssh]\naccept = 127.0.0.1:8383\nconnect = "+host+":"+port+"\nsni = "+sni+":443\n";
				fileOutputStream.write(conf.getBytes());
				fileOutputStream.close();
			} catch (IOException e) {
				Log.e(TAG, "Failed config file creation: ", e);
				try {
					// attempt to finally close the file
					fileOutputStream.close();
				} catch (IOException e1) {
					// ignore exception
				}

			}
		} catch (Exception e) {
			Log.e(TAG, "Failed config file creation: ", e);

		}
	}

    public static String readLog() {
        File file = new File(new StringBuilder().append(context.getFilesDir().getPath()).append("log").toString());
        if (!file.exists()) {
            return "";
        }
        try {
            InputStream inputStream = new FileInputStream(file);
            byte[] readInputStream = readInputStream(inputStream);
            if (readInputStream == null) {
                return (String) null;
            }
            return new String(readInputStream, "UTF-8");
        } catch (Exception e) {
            Exception exception = e;
            return (String) null;
        }
    }

    public static byte[] readInputStream(InputStream inputStream) {
        byte[] bArr = new byte[512];
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        while (true) {
            try {
                int read = inputStream.read(bArr);
                int i = read;
                if (read <= -1) {
                    return byteArrayOutputStream.toByteArray();
                }
                byteArrayOutputStream.write(bArr, 0, i);
            } catch (Exception e) {
                return (byte[]) null;
            }
        }
    }
}

