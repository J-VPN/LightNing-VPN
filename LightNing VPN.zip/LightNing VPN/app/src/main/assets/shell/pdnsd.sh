#!/system/bin/sh

DIR=/data/data/ssh.privatecon.vpn/files
CDIR=/data/data/ssh.privatecon.vpn/cache

PATH=$DIR:$PATH

case $1 in
 start)
 echo "
global {
 perm_cache = 1024;
 cache_dir = $CDIR;
 server_ip = $2;
 server_port = 8395;
 query_method = tcp_only;
 min_ttl = 15m;
 max_ttl = 1w;
 timeout = 10;
 daemon = on;
}

server {
 label = primary;
 ip = $3;
 uptest = none;
}

server {
 label = secondary;
 ip = $4;
 uptest = none;
}

rr {
 name=localhost;
 reverse=on;
 a=127.0.0.1;
 owner=localhost;
 soa=localhost,root.localhost,42,86400,900,86400,86400;
}
" >|$DIR/pdnsd.conf

  if [[ ! -e $CDIR ]]; then
   mkdir $CDIR
  fi

  if [[ ! -e $CDIR/pdnsd.cache ]]; then
   echo "" >>$CDIR/pdnsd.cache
  fi

 $DIR/pdnsd -p $DIR/pdnsd.pid -c $DIR/pdnsd.conf

 ;;
 stop)

  if [ -e $DIR/pdnsd.pid ]; then
     kill -15 `cat $DIR/pdnsd.pid`
     rm $DIR/pdnsd.pid
    else
     killall -15 pdnsd
     busybox killall -15 pdnsd
    fi

  rm $DIR/pdnsd.conf
  rm $CDIR/pdnsd.cache

  ;;
esac
